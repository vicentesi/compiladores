// $ANTLR 3.3 Nov 30, 2010 12:45:30 /home/gpqcom/CCO/compiladores/FINAL/javax.g 2011-04-12 14:56:29

	package Tools;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class javaxParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "SEMI", "NAME", "ASSIGN", "COMMA", "LPAREN", "RPAREN", "DOSTAT", "ENDSTAT", "IFSTAT", "THENSTAT", "ELSEIFSTAT", "ELSESTAT", "FORSTAT", "INSTAT", "REPEATSTAT", "UNTILSTAT", "CHESTSTAT", "WITHSTAT", "TYPE", "DOT", "RETURNSTAT", "PLUS", "MINUS", "STAR", "SLASH", "PERCENT", "POWER", "LESS", "TO", "LESSEQUAL", "GREATER", "GREATEREQUAL", "EQUAL", "AND", "OR", "NOTEQUAL", "NOT", "INT", "FLOAT", "HEX", "NORMALSTRING", "LBRACK", "RBRACK", "COLON", "LCURLY", "RCURLY", "EscapeSequence", "WS", "COMMENT", "LINE_COMMENT", "'false'", "'true'"
    };
    public static final int EOF=-1;
    public static final int T__54=54;
    public static final int T__55=55;
    public static final int SEMI=4;
    public static final int NAME=5;
    public static final int ASSIGN=6;
    public static final int COMMA=7;
    public static final int LPAREN=8;
    public static final int RPAREN=9;
    public static final int DOSTAT=10;
    public static final int ENDSTAT=11;
    public static final int IFSTAT=12;
    public static final int THENSTAT=13;
    public static final int ELSEIFSTAT=14;
    public static final int ELSESTAT=15;
    public static final int FORSTAT=16;
    public static final int INSTAT=17;
    public static final int REPEATSTAT=18;
    public static final int UNTILSTAT=19;
    public static final int CHESTSTAT=20;
    public static final int WITHSTAT=21;
    public static final int TYPE=22;
    public static final int DOT=23;
    public static final int RETURNSTAT=24;
    public static final int PLUS=25;
    public static final int MINUS=26;
    public static final int STAR=27;
    public static final int SLASH=28;
    public static final int PERCENT=29;
    public static final int POWER=30;
    public static final int LESS=31;
    public static final int TO=32;
    public static final int LESSEQUAL=33;
    public static final int GREATER=34;
    public static final int GREATEREQUAL=35;
    public static final int EQUAL=36;
    public static final int AND=37;
    public static final int OR=38;
    public static final int NOTEQUAL=39;
    public static final int NOT=40;
    public static final int INT=41;
    public static final int FLOAT=42;
    public static final int HEX=43;
    public static final int NORMALSTRING=44;
    public static final int LBRACK=45;
    public static final int RBRACK=46;
    public static final int COLON=47;
    public static final int LCURLY=48;
    public static final int RCURLY=49;
    public static final int EscapeSequence=50;
    public static final int WS=51;
    public static final int COMMENT=52;
    public static final int LINE_COMMENT=53;



        public javaxParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public javaxParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return javaxParser.tokenNames; }
    public String getGrammarFileName() { return "/home/gpqcom/CCO/compiladores/FINAL/javax.g"; }



    // $ANTLR start "chunk"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:1: chunk : ( stat ( SEMI )? )+ ;
    public final void chunk() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:7: ( ( stat ( SEMI )? )+ )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:9: ( stat ( SEMI )? )+
            {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:9: ( stat ( SEMI )? )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==NAME||LA2_0==IFSTAT||LA2_0==FORSTAT||LA2_0==REPEATSTAT||LA2_0==CHESTSTAT||LA2_0==TYPE||LA2_0==RETURNSTAT) ) {
                    alt2=1;
                    
                }
                

                switch (alt2) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:10: stat ( SEMI )?
            	    {
            	    pushFollow(FOLLOW_stat_in_chunk36);
            	    stat();
            	    
            	    state._fsp--;

            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:15: ( SEMI )?
            	    int alt1=2;
            	    int LA1_0 = input.LA(1);

            	    if ( (LA1_0==SEMI) ) {
            	        alt1=1;
            	        
            	    }
            	    switch (alt1) {
            	        case 1 :
            	            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:17:16: SEMI
            	            {
            	            match(input,SEMI,FOLLOW_SEMI_in_chunk39); 
            	            
            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

        }
        catch (RecognitionException re) {
        	
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "chunk"


    // $ANTLR start "stat"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:19:1: stat : ( weakstat | deffunc | defchest );
    public final void stat() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:19:6: ( weakstat | deffunc | defchest )
            int alt3=3;
            switch ( input.LA(1) ) {
            case NAME:
                {
                int LA3_1 = input.LA(2);

                if ( (LA3_1==ASSIGN||LA3_1==LPAREN||LA3_1==DOT) ) {
                    alt3=1;
                }
                else if ( (LA3_1==NAME) ) {
                    int LA3_5 = input.LA(3);

                    if ( (LA3_5==LPAREN) ) {
                        alt3=2;
                    }
                    else if ( (LA3_5==SEMI||LA3_5==COMMA) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 5, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;
                }
                }
                break;
            case TYPE:
                {
                int LA3_2 = input.LA(2);

                if ( (LA3_2==NAME) ) {
                    int LA3_5 = input.LA(3);

                    if ( (LA3_5==LPAREN) ) {
                        alt3=2;
                    }
                    else if ( (LA3_5==SEMI||LA3_5==COMMA) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 5, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 2, input);

                    throw nvae;
                }
                }
                break;
            case IFSTAT:
            case FORSTAT:
            case REPEATSTAT:
            case RETURNSTAT:
                {
                alt3=1;
                }
                break;
            case CHESTSTAT:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:19:9: weakstat
                    {
                    pushFollow(FOLLOW_weakstat_in_stat52);
                    weakstat();

                    state._fsp--;


                    }
                    break;
                case 2 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:20:2: deffunc
                    {
                    pushFollow(FOLLOW_deffunc_in_stat57);
                    deffunc();

                    state._fsp--;


                    }
                    break;
                case 3 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:21:2: defchest
                    {
                    pushFollow(FOLLOW_defchest_in_stat64);
                    defchest();

                    state._fsp--;


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "stat"


    // $ANTLR start "weakstat"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:23:1: weakstat : ( varatrib SEMI | vardecl SEMI | funccall SEMI | defif | deffor | defreturn SEMI | chestaccess SEMI | defrepeat );
    public final void weakstat() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:23:10: ( varatrib SEMI | vardecl SEMI | funccall SEMI | defif | deffor | defreturn SEMI | chestaccess SEMI | defrepeat )
            int alt4=8;
            alt4 = dfa4.predict(input);
            switch (alt4) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:24:2: varatrib SEMI
                    {
                    pushFollow(FOLLOW_varatrib_in_weakstat74);
                    varatrib();

                    state._fsp--;

                    match(input,SEMI,FOLLOW_SEMI_in_weakstat76); 

                    }
                    break;
                case 2 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:25:2: vardecl SEMI
                    {
                    pushFollow(FOLLOW_vardecl_in_weakstat81);
                    vardecl();

                    state._fsp--;

                    match(input,SEMI,FOLLOW_SEMI_in_weakstat87); 

                    }
                    break;
                case 3 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:26:2: funccall SEMI
                    {
                    pushFollow(FOLLOW_funccall_in_weakstat92);
                    funccall();

                    state._fsp--;

                    match(input,SEMI,FOLLOW_SEMI_in_weakstat94); 

                    }
                    break;
                case 4 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:27:2: defif
                    {
                    pushFollow(FOLLOW_defif_in_weakstat99);
                    defif();

                    state._fsp--;


                    }
                    break;
                case 5 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:28:2: deffor
                    {
                    pushFollow(FOLLOW_deffor_in_weakstat107);
                    deffor();

                    state._fsp--;


                    }
                    break;
                case 6 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:29:2: defreturn SEMI
                    {
                    pushFollow(FOLLOW_defreturn_in_weakstat115);
                    defreturn();

                    state._fsp--;

                    match(input,SEMI,FOLLOW_SEMI_in_weakstat117); 

                    }
                    break;
                case 7 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:30:2: chestaccess SEMI
                    {
                    pushFollow(FOLLOW_chestaccess_in_weakstat122);
                    chestaccess();

                    state._fsp--;

                    match(input,SEMI,FOLLOW_SEMI_in_weakstat124); 

                    }
                    break;
                case 8 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:31:2: defrepeat
                    {
                    pushFollow(FOLLOW_defrepeat_in_weakstat132);
                    defrepeat();

                    state._fsp--;


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "weakstat"


    // $ANTLR start "block"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:33:1: block : ( weakstat )* ;
    public final void block() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:33:7: ( ( weakstat )* )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:33:9: ( weakstat )*
            {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:33:9: ( weakstat )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==NAME||LA5_0==IFSTAT||LA5_0==FORSTAT||LA5_0==REPEATSTAT||LA5_0==TYPE||LA5_0==RETURNSTAT) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:33:10: weakstat
            	    {
            	    pushFollow(FOLLOW_weakstat_in_block141);
            	    weakstat();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "block"


    // $ANTLR start "varatrib"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:35:1: varatrib : ( NAME | chestaccess ) ASSIGN expr ;
    public final void varatrib() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:35:10: ( ( NAME | chestaccess ) ASSIGN expr )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:35:12: ( NAME | chestaccess ) ASSIGN expr
            {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:35:12: ( NAME | chestaccess )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==NAME) ) {
                int LA6_1 = input.LA(2);

                if ( (LA6_1==ASSIGN) ) {
                    alt6=1;
                }
                else if ( (LA6_1==DOT) ) {
                    alt6=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:35:13: NAME
                    {
                    match(input,NAME,FOLLOW_NAME_in_varatrib152); 

                    }
                    break;
                case 2 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:35:20: chestaccess
                    {
                    pushFollow(FOLLOW_chestaccess_in_varatrib156);
                    chestaccess();

                    state._fsp--;


                    }
                    break;

            }

            match(input,ASSIGN,FOLLOW_ASSIGN_in_varatrib159); 
            pushFollow(FOLLOW_expr_in_varatrib161);
            expr();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "varatrib"


    // $ANTLR start "vardecl"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:37:1: vardecl : type NAME ( COMMA NAME )* ;
    public final void vardecl() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:37:9: ( type NAME ( COMMA NAME )* )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:37:11: type NAME ( COMMA NAME )*
            {
            pushFollow(FOLLOW_type_in_vardecl169);
            type();

            state._fsp--;

            match(input,NAME,FOLLOW_NAME_in_vardecl171); 
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:37:20: ( COMMA NAME )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==COMMA) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:37:21: COMMA NAME
            	    {
            	    match(input,COMMA,FOLLOW_COMMA_in_vardecl173); 
            	    match(input,NAME,FOLLOW_NAME_in_vardecl175); 

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "vardecl"


    // $ANTLR start "funccall"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:39:1: funccall : NAME LPAREN arglist RPAREN ;
    public final void funccall() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:39:10: ( NAME LPAREN arglist RPAREN )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:39:12: NAME LPAREN arglist RPAREN
            {
            match(input,NAME,FOLLOW_NAME_in_funccall185); 
            match(input,LPAREN,FOLLOW_LPAREN_in_funccall187); 
            pushFollow(FOLLOW_arglist_in_funccall189);
            arglist();

            state._fsp--;

            match(input,RPAREN,FOLLOW_RPAREN_in_funccall191); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "funccall"


    // $ANTLR start "deffunc"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:41:1: deffunc : type NAME LPAREN typedarglist RPAREN DOSTAT block ENDSTAT ;
    public final void deffunc() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:41:9: ( type NAME LPAREN typedarglist RPAREN DOSTAT block ENDSTAT )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:41:11: type NAME LPAREN typedarglist RPAREN DOSTAT block ENDSTAT
            {
            pushFollow(FOLLOW_type_in_deffunc199);
            type();

            state._fsp--;

            match(input,NAME,FOLLOW_NAME_in_deffunc201); 
            match(input,LPAREN,FOLLOW_LPAREN_in_deffunc203); 
            pushFollow(FOLLOW_typedarglist_in_deffunc205);
            typedarglist();

            state._fsp--;

            match(input,RPAREN,FOLLOW_RPAREN_in_deffunc207); 
            match(input,DOSTAT,FOLLOW_DOSTAT_in_deffunc209); 
            pushFollow(FOLLOW_block_in_deffunc211);
            block();

            state._fsp--;

            match(input,ENDSTAT,FOLLOW_ENDSTAT_in_deffunc213); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "deffunc"


    // $ANTLR start "defif"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:1: defif : IFSTAT expr THENSTAT block ( ELSEIFSTAT expr THENSTAT block )* ( ELSESTAT block )? ENDSTAT ;
    public final void defif() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:7: ( IFSTAT expr THENSTAT block ( ELSEIFSTAT expr THENSTAT block )* ( ELSESTAT block )? ENDSTAT )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:9: IFSTAT expr THENSTAT block ( ELSEIFSTAT expr THENSTAT block )* ( ELSESTAT block )? ENDSTAT
            {
            match(input,IFSTAT,FOLLOW_IFSTAT_in_defif221); 
            pushFollow(FOLLOW_expr_in_defif223);
            expr();

            state._fsp--;

            match(input,THENSTAT,FOLLOW_THENSTAT_in_defif225); 
            pushFollow(FOLLOW_block_in_defif227);
            block();

            state._fsp--;

            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:36: ( ELSEIFSTAT expr THENSTAT block )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==ELSEIFSTAT) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:37: ELSEIFSTAT expr THENSTAT block
            	    {
            	    match(input,ELSEIFSTAT,FOLLOW_ELSEIFSTAT_in_defif230); 
            	    pushFollow(FOLLOW_expr_in_defif232);
            	    expr();

            	    state._fsp--;

            	    match(input,THENSTAT,FOLLOW_THENSTAT_in_defif234); 
            	    pushFollow(FOLLOW_block_in_defif236);
            	    block();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:70: ( ELSESTAT block )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==ELSESTAT) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:43:71: ELSESTAT block
                    {
                    match(input,ELSESTAT,FOLLOW_ELSESTAT_in_defif241); 
                    pushFollow(FOLLOW_block_in_defif243);
                    block();

                    state._fsp--;


                    }
                    break;

            }

            match(input,ENDSTAT,FOLLOW_ENDSTAT_in_defif247); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "defif"


    // $ANTLR start "deffor"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:45:1: deffor : FORSTAT NAME INSTAT expr DOSTAT block ENDSTAT ;
    public final void deffor() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:45:8: ( FORSTAT NAME INSTAT expr DOSTAT block ENDSTAT )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:45:10: FORSTAT NAME INSTAT expr DOSTAT block ENDSTAT
            {
            match(input,FORSTAT,FOLLOW_FORSTAT_in_deffor255); 
            match(input,NAME,FOLLOW_NAME_in_deffor257); 
            match(input,INSTAT,FOLLOW_INSTAT_in_deffor259); 
            pushFollow(FOLLOW_expr_in_deffor261);
            expr();

            state._fsp--;

            match(input,DOSTAT,FOLLOW_DOSTAT_in_deffor263); 
            pushFollow(FOLLOW_block_in_deffor265);
            block();

            state._fsp--;

            match(input,ENDSTAT,FOLLOW_ENDSTAT_in_deffor267); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "deffor"


    // $ANTLR start "defrepeat"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:47:1: defrepeat : REPEATSTAT block UNTILSTAT expr ENDSTAT ;
    public final void defrepeat() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:47:11: ( REPEATSTAT block UNTILSTAT expr ENDSTAT )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:47:13: REPEATSTAT block UNTILSTAT expr ENDSTAT
            {
            match(input,REPEATSTAT,FOLLOW_REPEATSTAT_in_defrepeat275); 
            pushFollow(FOLLOW_block_in_defrepeat277);
            block();

            state._fsp--;

            match(input,UNTILSTAT,FOLLOW_UNTILSTAT_in_defrepeat279); 
            pushFollow(FOLLOW_expr_in_defrepeat281);
            expr();

            state._fsp--;

            match(input,ENDSTAT,FOLLOW_ENDSTAT_in_defrepeat283); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "defrepeat"


    // $ANTLR start "defchest"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:49:1: defchest : CHESTSTAT NAME WITHSTAT ( vardecl SEMI )* ENDSTAT ;
    public final void defchest() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:49:10: ( CHESTSTAT NAME WITHSTAT ( vardecl SEMI )* ENDSTAT )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:49:12: CHESTSTAT NAME WITHSTAT ( vardecl SEMI )* ENDSTAT
            {
            match(input,CHESTSTAT,FOLLOW_CHESTSTAT_in_defchest291); 
            match(input,NAME,FOLLOW_NAME_in_defchest293); 
            match(input,WITHSTAT,FOLLOW_WITHSTAT_in_defchest295); 
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:49:36: ( vardecl SEMI )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==NAME||LA10_0==TYPE) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:49:37: vardecl SEMI
            	    {
            	    pushFollow(FOLLOW_vardecl_in_defchest298);
            	    vardecl();

            	    state._fsp--;

            	    match(input,SEMI,FOLLOW_SEMI_in_defchest300); 

            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            match(input,ENDSTAT,FOLLOW_ENDSTAT_in_defchest304); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "defchest"


    // $ANTLR start "type"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:51:1: type : ( TYPE | NAME );
    public final void type() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:51:6: ( TYPE | NAME )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:
            {
            if ( input.LA(1)==NAME||input.LA(1)==TYPE ) {
                input.consume();
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "type"


    // $ANTLR start "expr"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:1: expr : ( 'false' | 'true' | number | string | funccall | unop | chestaccess | NAME ) ( binop expr )* ;
    public final void expr() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:6: ( ( 'false' | 'true' | number | string | funccall | unop | chestaccess | NAME ) ( binop expr )* )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:8: ( 'false' | 'true' | number | string | funccall | unop | chestaccess | NAME ) ( binop expr )*
            {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:8: ( 'false' | 'true' | number | string | funccall | unop | chestaccess | NAME )
            int alt11=8;
            alt11 = dfa11.predict(input);
            switch (alt11) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:9: 'false'
                    {
                    match(input,54,FOLLOW_54_in_expr325); 

                    }
                    break;
                case 2 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:19: 'true'
                    {
                    match(input,55,FOLLOW_55_in_expr329); 

                    }
                    break;
                case 3 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:28: number
                    {
                    pushFollow(FOLLOW_number_in_expr333);
                    number();

                    state._fsp--;


                    }
                    break;
                case 4 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:37: string
                    {
                    pushFollow(FOLLOW_string_in_expr337);
                    string();

                    state._fsp--;


                    }
                    break;
                case 5 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:46: funccall
                    {
                    pushFollow(FOLLOW_funccall_in_expr341);
                    funccall();

                    state._fsp--;


                    }
                    break;
                case 6 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:57: unop
                    {
                    pushFollow(FOLLOW_unop_in_expr345);
                    unop();

                    state._fsp--;


                    }
                    break;
                case 7 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:64: chestaccess
                    {
                    pushFollow(FOLLOW_chestaccess_in_expr349);
                    chestaccess();

                    state._fsp--;


                    }
                    break;
                case 8 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:78: NAME
                    {
                    match(input,NAME,FOLLOW_NAME_in_expr353); 

                    }
                    break;

            }

            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:84: ( binop expr )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=PLUS && LA12_0<=NOTEQUAL)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:53:85: binop expr
            	    {
            	    pushFollow(FOLLOW_binop_in_expr357);
            	    binop();

            	    state._fsp--;

            	    pushFollow(FOLLOW_expr_in_expr359);
            	    expr();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "expr"


    // $ANTLR start "arglist"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:1: arglist : ( expr ( COMMA expr )* )? ;
    public final void arglist() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:9: ( ( expr ( COMMA expr )* )? )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:11: ( expr ( COMMA expr )* )?
            {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:11: ( expr ( COMMA expr )* )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==NAME||LA14_0==MINUS||(LA14_0>=NOT && LA14_0<=NORMALSTRING)||(LA14_0>=54 && LA14_0<=55)) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:12: expr ( COMMA expr )*
                    {
                    pushFollow(FOLLOW_expr_in_arglist370);
                    expr();

                    state._fsp--;

                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:16: ( COMMA expr )*
                    loop13:
                    do {
                        int alt13=2;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0==COMMA) ) {
                            alt13=1;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:55:17: COMMA expr
                    	    {
                    	    match(input,COMMA,FOLLOW_COMMA_in_arglist372); 
                    	    pushFollow(FOLLOW_expr_in_arglist374);
                    	    expr();

                    	    state._fsp--;


                    	    }
                    	    break;

                    	default :
                    	    break loop13;
                        }
                    } while (true);


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "arglist"


    // $ANTLR start "typedarglist"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:1: typedarglist : ( type NAME ( COMMA type NAME )* )? ;
    public final void typedarglist() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:14: ( ( type NAME ( COMMA type NAME )* )? )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:16: ( type NAME ( COMMA type NAME )* )?
            {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:16: ( type NAME ( COMMA type NAME )* )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==NAME||LA16_0==TYPE) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:17: type NAME ( COMMA type NAME )*
                    {
                    pushFollow(FOLLOW_type_in_typedarglist387);
                    type();

                    state._fsp--;

                    match(input,NAME,FOLLOW_NAME_in_typedarglist389); 
                    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:26: ( COMMA type NAME )*
                    loop15:
                    do {
                        int alt15=2;
                        int LA15_0 = input.LA(1);

                        if ( (LA15_0==COMMA) ) {
                            alt15=1;
                        }


                        switch (alt15) {
                    	case 1 :
                    	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:57:27: COMMA type NAME
                    	    {
                    	    match(input,COMMA,FOLLOW_COMMA_in_typedarglist391); 
                    	    pushFollow(FOLLOW_type_in_typedarglist393);
                    	    type();

                    	    state._fsp--;

                    	    match(input,NAME,FOLLOW_NAME_in_typedarglist395); 

                    	    }
                    	    break;

                    	default :
                    	    break loop15;
                        }
                    } while (true);


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "typedarglist"


    // $ANTLR start "chestaccess"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:59:1: chestaccess : NAME ( DOT NAME )+ ;
    public final void chestaccess() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:59:13: ( NAME ( DOT NAME )+ )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:59:15: NAME ( DOT NAME )+
            {
            match(input,NAME,FOLLOW_NAME_in_chestaccess407); 
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:59:19: ( DOT NAME )+
            int cnt17=0;
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==DOT) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:59:20: DOT NAME
            	    {
            	    match(input,DOT,FOLLOW_DOT_in_chestaccess409); 
            	    match(input,NAME,FOLLOW_NAME_in_chestaccess411); 

            	    }
            	    break;

            	default :
            	    if ( cnt17 >= 1 ) break loop17;
                        EarlyExitException eee =
                            new EarlyExitException(17, input);
                        throw eee;
                }
                cnt17++;
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "chestaccess"


    // $ANTLR start "defreturn"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:61:1: defreturn : RETURNSTAT expr ;
    public final void defreturn() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:61:11: ( RETURNSTAT expr )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:61:13: RETURNSTAT expr
            {
            match(input,RETURNSTAT,FOLLOW_RETURNSTAT_in_defreturn421); 
            pushFollow(FOLLOW_expr_in_defreturn423);
            expr();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "defreturn"


    // $ANTLR start "binop"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:63:1: binop : ( PLUS | MINUS | STAR | SLASH | PERCENT | POWER | LESS | TO | LESSEQUAL | GREATER | GREATEREQUAL | EQUAL | AND | OR | NOTEQUAL );
    public final void binop() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:63:7: ( PLUS | MINUS | STAR | SLASH | PERCENT | POWER | LESS | TO | LESSEQUAL | GREATER | GREATEREQUAL | EQUAL | AND | OR | NOTEQUAL )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:
            {
            if ( (input.LA(1)>=PLUS && input.LA(1)<=NOTEQUAL) ) {
                input.consume();
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "binop"


    // $ANTLR start "unop"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:66:1: unop : ( MINUS | NOT );
    public final void unop() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:66:6: ( MINUS | NOT )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:
            {
            if ( input.LA(1)==MINUS||input.LA(1)==NOT ) {
                input.consume();
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "unop"


    // $ANTLR start "number"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:68:1: number : ( INT | FLOAT | HEX );
    public final void number() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:68:8: ( INT | FLOAT | HEX )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:
            {
            if ( (input.LA(1)>=INT && input.LA(1)<=HEX) ) {
                input.consume();
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "number"


    // $ANTLR start "string"
    // /home/gpqcom/CCO/compiladores/FINAL/javax.g:70:1: string : NORMALSTRING ;
    public final void string() throws RecognitionException {
        try {
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:70:8: ( NORMALSTRING )
            // /home/gpqcom/CCO/compiladores/FINAL/javax.g:70:10: NORMALSTRING
            {
            match(input,NORMALSTRING,FOLLOW_NORMALSTRING_in_string525); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "string"

    // Delegated rules


    protected DFA4 dfa4 = new DFA4(this);
    protected DFA11 dfa11 = new DFA11(this);
    static final String DFA4_eotS =
        "\14\uffff";
    static final String DFA4_eofS =
        "\14\uffff";
    static final String DFA4_minS =
        "\2\5\7\uffff\1\5\1\4\1\uffff";
    static final String DFA4_maxS =
        "\1\30\1\27\7\uffff\1\5\1\27\1\uffff";
    static final String DFA4_acceptS =
        "\2\uffff\1\2\1\4\1\5\1\6\1\10\1\3\1\1\2\uffff\1\7";
    static final String DFA4_specialS =
        "\14\uffff}>";
    static final String[] DFA4_transitionS = {
            "\1\1\6\uffff\1\3\3\uffff\1\4\1\uffff\1\6\3\uffff\1\2\1\uffff"+
            "\1\5",
            "\1\2\1\10\1\uffff\1\7\16\uffff\1\11",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\12",
            "\1\13\1\uffff\1\10\20\uffff\1\11",
            ""
    };

    static final short[] DFA4_eot = DFA.unpackEncodedString(DFA4_eotS);
    static final short[] DFA4_eof = DFA.unpackEncodedString(DFA4_eofS);
    static final char[] DFA4_min = DFA.unpackEncodedStringToUnsignedChars(DFA4_minS);
    static final char[] DFA4_max = DFA.unpackEncodedStringToUnsignedChars(DFA4_maxS);
    static final short[] DFA4_accept = DFA.unpackEncodedString(DFA4_acceptS);
    static final short[] DFA4_special = DFA.unpackEncodedString(DFA4_specialS);
    static final short[][] DFA4_transition;

    static {
        int numStates = DFA4_transitionS.length;
        DFA4_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA4_transition[i] = DFA.unpackEncodedString(DFA4_transitionS[i]);
        }
    }

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = DFA4_eot;
            this.eof = DFA4_eof;
            this.min = DFA4_min;
            this.max = DFA4_max;
            this.accept = DFA4_accept;
            this.special = DFA4_special;
            this.transition = DFA4_transition;
        }
        public String getDescription() {
            return "23:1: weakstat : ( varatrib SEMI | vardecl SEMI | funccall SEMI | defif | deffor | defreturn SEMI | chestaccess SEMI | defrepeat );";
        }
    }
    static final String DFA11_eotS =
        "\12\uffff";
    static final String DFA11_eofS =
        "\12\uffff";
    static final String DFA11_minS =
        "\1\5\4\uffff\1\4\4\uffff";
    static final String DFA11_maxS =
        "\1\67\4\uffff\1\47\4\uffff";
    static final String DFA11_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\uffff\1\6\1\5\1\7\1\10";
    static final String DFA11_specialS =
        "\12\uffff}>";
    static final String[] DFA11_transitionS = {
            "\1\5\24\uffff\1\6\15\uffff\1\6\3\3\1\4\11\uffff\1\1\1\2",
            "",
            "",
            "",
            "",
            "\1\11\2\uffff\1\11\1\7\3\11\1\uffff\1\11\11\uffff\1\10\1\uffff"+
            "\17\11",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA11_eot = DFA.unpackEncodedString(DFA11_eotS);
    static final short[] DFA11_eof = DFA.unpackEncodedString(DFA11_eofS);
    static final char[] DFA11_min = DFA.unpackEncodedStringToUnsignedChars(DFA11_minS);
    static final char[] DFA11_max = DFA.unpackEncodedStringToUnsignedChars(DFA11_maxS);
    static final short[] DFA11_accept = DFA.unpackEncodedString(DFA11_acceptS);
    static final short[] DFA11_special = DFA.unpackEncodedString(DFA11_specialS);
    static final short[][] DFA11_transition;

    static {
        int numStates = DFA11_transitionS.length;
        DFA11_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA11_transition[i] = DFA.unpackEncodedString(DFA11_transitionS[i]);
        }
    }

    class DFA11 extends DFA {

        public DFA11(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 11;
            this.eot = DFA11_eot;
            this.eof = DFA11_eof;
            this.min = DFA11_min;
            this.max = DFA11_max;
            this.accept = DFA11_accept;
            this.special = DFA11_special;
            this.transition = DFA11_transition;
        }
        public String getDescription() {
            return "53:8: ( 'false' | 'true' | number | string | funccall | unop | chestaccess | NAME )";
        }
    }
 

    public static final BitSet FOLLOW_stat_in_chunk36 = new BitSet(new long[]{0x0000000001551032L});
    public static final BitSet FOLLOW_SEMI_in_chunk39 = new BitSet(new long[]{0x0000000001551032L});
    public static final BitSet FOLLOW_weakstat_in_stat52 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_deffunc_in_stat57 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_defchest_in_stat64 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_varatrib_in_weakstat74 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_weakstat76 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_vardecl_in_weakstat81 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_weakstat87 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_funccall_in_weakstat92 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_weakstat94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_defif_in_weakstat99 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_deffor_in_weakstat107 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_defreturn_in_weakstat115 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_weakstat117 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_chestaccess_in_weakstat122 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_weakstat124 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_defrepeat_in_weakstat132 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_weakstat_in_block141 = new BitSet(new long[]{0x0000000001451022L});
    public static final BitSet FOLLOW_NAME_in_varatrib152 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_chestaccess_in_varatrib156 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_ASSIGN_in_varatrib159 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_varatrib161 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_vardecl169 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_vardecl171 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_COMMA_in_vardecl173 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_vardecl175 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_NAME_in_funccall185 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_LPAREN_in_funccall187 = new BitSet(new long[]{0x00C01F0004000220L});
    public static final BitSet FOLLOW_arglist_in_funccall189 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_RPAREN_in_funccall191 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_deffunc199 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_deffunc201 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_LPAREN_in_deffunc203 = new BitSet(new long[]{0x0000000000400220L});
    public static final BitSet FOLLOW_typedarglist_in_deffunc205 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_RPAREN_in_deffunc207 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_DOSTAT_in_deffunc209 = new BitSet(new long[]{0x0000000001451820L});
    public static final BitSet FOLLOW_block_in_deffunc211 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_ENDSTAT_in_deffunc213 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IFSTAT_in_defif221 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_defif223 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_THENSTAT_in_defif225 = new BitSet(new long[]{0x000000000145D820L});
    public static final BitSet FOLLOW_block_in_defif227 = new BitSet(new long[]{0x000000000000C800L});
    public static final BitSet FOLLOW_ELSEIFSTAT_in_defif230 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_defif232 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_THENSTAT_in_defif234 = new BitSet(new long[]{0x000000000145D820L});
    public static final BitSet FOLLOW_block_in_defif236 = new BitSet(new long[]{0x000000000000C800L});
    public static final BitSet FOLLOW_ELSESTAT_in_defif241 = new BitSet(new long[]{0x0000000001451820L});
    public static final BitSet FOLLOW_block_in_defif243 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_ENDSTAT_in_defif247 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FORSTAT_in_deffor255 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_deffor257 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_INSTAT_in_deffor259 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_deffor261 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_DOSTAT_in_deffor263 = new BitSet(new long[]{0x0000000001451820L});
    public static final BitSet FOLLOW_block_in_deffor265 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_ENDSTAT_in_deffor267 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REPEATSTAT_in_defrepeat275 = new BitSet(new long[]{0x00000000014D1020L});
    public static final BitSet FOLLOW_block_in_defrepeat277 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_UNTILSTAT_in_defrepeat279 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_defrepeat281 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_ENDSTAT_in_defrepeat283 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CHESTSTAT_in_defchest291 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_defchest293 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_WITHSTAT_in_defchest295 = new BitSet(new long[]{0x0000000000400820L});
    public static final BitSet FOLLOW_vardecl_in_defchest298 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_defchest300 = new BitSet(new long[]{0x0000000000400820L});
    public static final BitSet FOLLOW_ENDSTAT_in_defchest304 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_54_in_expr325 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_55_in_expr329 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_number_in_expr333 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_string_in_expr337 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_funccall_in_expr341 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_unop_in_expr345 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_chestaccess_in_expr349 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_NAME_in_expr353 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_binop_in_expr357 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_expr359 = new BitSet(new long[]{0x000000FFFE000002L});
    public static final BitSet FOLLOW_expr_in_arglist370 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_COMMA_in_arglist372 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_arglist374 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_type_in_typedarglist387 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_typedarglist389 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_COMMA_in_typedarglist391 = new BitSet(new long[]{0x0000000000400020L});
    public static final BitSet FOLLOW_type_in_typedarglist393 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_typedarglist395 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_NAME_in_chestaccess407 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_DOT_in_chestaccess409 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_NAME_in_chestaccess411 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_RETURNSTAT_in_defreturn421 = new BitSet(new long[]{0x00C01F0004000020L});
    public static final BitSet FOLLOW_expr_in_defreturn423 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_binop0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_unop0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_number0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NORMALSTRING_in_string525 = new BitSet(new long[]{0x0000000000000002L});

}
