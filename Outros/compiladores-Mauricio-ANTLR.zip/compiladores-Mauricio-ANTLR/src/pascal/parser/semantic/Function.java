package pascal.parser.semantic;

public class Function {

	private PascalTree tree;
	private boolean isFunctional;
	private Type type;
	private boolean hasReturn;

	public Function(PascalTree tree, boolean isFunctional, boolean hasReturn) {
		this.tree = tree;
		this.isFunctional = isFunctional;
		this.hasReturn = hasReturn;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return this.tree.getText();
	}

	public Type getType() {
		if (this.hasReturn && this.type == null) {
			System.err.println("Couldn't infer the type of " + tree.getText()
					+ " yet.");
		}
		return this.type;
	}

	public boolean isFunctional() {
		return this.isFunctional;
	}

	public void setType(Type type) {
		System.out.println("Type infered on " + tree.getText());
		this.type = type;
	}

}
