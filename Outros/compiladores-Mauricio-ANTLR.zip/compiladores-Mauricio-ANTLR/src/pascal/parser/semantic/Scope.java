package pascal.parser.semantic;

import java.util.HashMap;
import java.util.Map;

public class Scope {

	private Scope parentScope;
	protected Map<String, PascalTree> symbolTable;
	
	public Scope(Scope parent, boolean isFunction) {
		System.out.println("Pushing scope.");
		this.parentScope = parent;
		this.symbolTable = new HashMap<String, PascalTree>();
	}
	
	public boolean addSymbol(PascalTree symbol) {
		System.out.println("registering symbol: " + symbol.getToken().getText());
		if (this.symbolTable.containsKey(symbol.getToken().getText())) {
			System.err.println("Symbol redeclaration: " + symbol.getToken().getLine() + ", " + this.symbolTable.get(symbol.getToken().getText()).getLine());
			return false;
		}
		
		this.symbolTable.put(symbol.getToken().getText(), symbol);
		return true;
	}
	
	public boolean addSymbol(String name, Symbol symbol) {
		System.out.println("registering symbol: " + name);
		if (this.symbolTable.containsKey(name)) {
			System.err.println("Symbol redeclaration: " + name + ", " + this.symbolTable.get(name).getLine());
			return false;
		}
		
		PascalTree tree = new PascalTree(null);
		tree.symbol = symbol;
		this.symbolTable.put(name, tree);
		return true;
	}
	
	public Symbol resolveSymbol(String symbol) {
		symbol = symbol.toLowerCase();
		if (this.symbolTable.containsKey(symbol)) {
			return this.symbolTable.get(symbol).symbol;
		}
		
		if (this.parentScope != null) {
			return this.parentScope.resolveSymbol(symbol);
		}
		
		System.err.println("The symbol " + symbol + " wasn't declared.");
		return null;
	}

	public Scope getParentScope() {
		System.out.println("Popping scope.");
		return parentScope;
	}
	
	

}
