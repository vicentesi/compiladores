package pascal.parser.semantic;

import java.util.HashMap;
import java.util.Map;

public class GlobalScope extends Scope {

	private Map<String, Function> functionTable;

	public GlobalScope() {
		super(null, false);
		this.functionTable = new HashMap<String, Function>();
	}

	public boolean addFunction(Function function) {
		if (this.functionTable.containsKey(function.getName())) {
			if (this.functionTable.get(function.getName()).isFunctional()) {
				return true;
			}
			System.err.println("The function " + function.getName()
					+ " was already declared.");
			return false;
		}

		this.functionTable.put(function.getName(), function);
		return true;
	}

	public void addUse(PascalTree i1) {
		System.out.println("Using:");
		System.out.println(i1.getText());
	}

	public Type resolveFunction(String functionName) {
		if (this.functionTable.containsKey(functionName)) {
			return this.functionTable.get(functionName).getType();
		}

		System.err
				.println("The function " + functionName + " wasn't declared.");
		return null;
	}

}
