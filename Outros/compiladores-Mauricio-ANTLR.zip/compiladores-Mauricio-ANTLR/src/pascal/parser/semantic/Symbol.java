package pascal.parser.semantic;

public class Symbol {

	public Type type;

	public Type assign(Type t) {
		if (t == null
				|| !this.type.name.toLowerCase().equalsIgnoreCase(
						t.name.toLowerCase())) {
			System.out.println(t.name);
			System.out.println(this.type.name);
			return null;
		}
		return t;
	}
}
