package pascal.parser.semantic;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Type {

	public String name;
	public boolean isArray;
	public int begin, end;
	public Type arrayOf;

	private static Set<String> numericTypes;
	private static List<String> numericOrder;
	private static Set<String> textTypes;
	private static Set<String> logicalTypes;

	static {
		numericTypes = new HashSet<String>();
		numericTypes.add("integer");
		numericTypes.add("float");
		numericTypes.add("real");
		numericOrder = new ArrayList<String>();
		numericOrder.add("integer");
		numericOrder.add("float");
		numericOrder.add("real");

		textTypes = new HashSet<String>();
		textTypes.add("string");
		textTypes.add("char");

		logicalTypes = new HashSet<String>();
		logicalTypes.add("boolean");
	}

	public static Type plus(Type t1, Type t2) {
		return numberOperand(t1, t2);
	}

	private static Type numberOperand(Type t1, Type t2) {
		if (t1 == null || t2 == null) {
			return null;
		}
		if (!numericTypes.contains(t1.name.toLowerCase())) {
			return null;
		}
		if (!numericTypes.contains(t2.name.toLowerCase())) {
			return null;
		}

		int t1Order = numericOrder.indexOf(t1.name.toLowerCase());
		int t2Order = numericOrder.indexOf(t2.name.toLowerCase());
		int greater = (t1Order > t2Order) ? t1Order : t2Order;
		Type returnType = new Type();
		returnType.name = numericOrder.get(greater);
		return returnType;
	}

	public static Type minus(Type t1, Type t2) {
		return numberOperand(t1, t2);
	}

	public static Type times(Type t1, Type t2) {
		return numberOperand(t1, t2);
	}

	public static Type slash(Type t1, Type t2) {
		return numberOperand(t1, t2);
	}

	public static boolean lessThan(Type e1, Type e2) {
		return numberLogicOperand(e1, e2);
	}

	private static boolean numberLogicOperand(Type e1, Type e2) {
		if (e1 != null && e2 != null) {
			if (!numericTypes.contains(e1.name.toLowerCase())) {
				System.err.println("Invalid operator.");
				System.out.println(e1.name);
				return false;
			}
			if (!numericTypes.contains(e2.name.toLowerCase())) {
				System.err.println("Invalid operator.");
				System.out.println(e2.name);
				return false;
			}
			
			return true;
		} else {
			System.err.println("Null types.");
		}
		
		return false;
	}

	public static boolean greaterThan(Type e1, Type e2) {
		return numberLogicOperand(e1, e2);
	}

	public static boolean greatEqualThan(Type e1, Type e2) {
		return numberLogicOperand(e1, e2);
	}

	public static boolean lessEqualThan(Type e1, Type e2) {
		return numberLogicOperand(e1, e2);
	}

	public static boolean different(Type e1, Type e2) {
		return booleanOperand(e1, e2);
	}

	private static boolean booleanOperand(Type e1, Type e2) {
		if (e1 != null && e2 != null) {
			System.out.println(e1.name);
			System.out.println(e2.name);
			if (!logicalTypes.contains(e1.name.toLowerCase())) {
				System.err.println("Invalid logic operator.");
				return false;
			}

			if (!logicalTypes.contains(e2.name.toLowerCase())) {
				System.err.println("Invalid logic operator.");
				return false;
			}
			
			return true;
		} else {
			System.err.println("Null types.");
		}
		
		return false;
	}

	public static boolean equals(Type e1, Type e2) {
		return numericOrBooleanOperand(e1, e2);
	}

	private static boolean numericOrBooleanOperand(Type e1, Type e2) {
		if (e1 != null && e2 != null) {
			boolean e1IsLogical = logicalTypes.contains(e1.name);
			if (e1IsLogical) {
				return booleanOperand(e1, e2);
			} else {
				return numberLogicOperand(e1, e2);
			}
		} else {
			System.err.println("Null types.");
			return false;
		}
	}
}
