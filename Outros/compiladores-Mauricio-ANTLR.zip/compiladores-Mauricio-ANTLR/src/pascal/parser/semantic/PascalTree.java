package pascal.parser.semantic;

import org.antlr.runtime.Token;
import org.antlr.runtime.tree.CommonTree;

public class PascalTree extends CommonTree {
	
	public Symbol symbol;
	
	public PascalTree(Token t) {
		super(t);
		symbol = new Symbol();
	}

}
