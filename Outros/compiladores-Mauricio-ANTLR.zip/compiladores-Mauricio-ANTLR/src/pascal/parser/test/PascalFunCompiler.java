package pascal.parser.test;

import java.io.IOException;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.antlr.runtime.TokenRewriteStream;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.CommonTreeAdaptor;
import org.antlr.runtime.tree.CommonTreeNodeStream;
import org.antlr.runtime.tree.TreeAdaptor;

import pascal.parser.PascalFunLexer;
import pascal.parser.PascalFunParser;
import pascal.parser.PascalFunTreeWalker;
import pascal.parser.semantic.PascalTree;

public class PascalFunCompiler {
	
	public static TreeAdaptor pascalAdaptor = new CommonTreeAdaptor() {
		@Override
		public Object create(Token token) {
	        return new PascalTree(token);
	    }
		
		@Override
	    public Object dupNode(Object t) {
	        if ( t==null ) {
	            return null;
	        }
	        return create(((PascalTree)t).token);
	    }
	};

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("begin of analysis...");
		CharStream cs = null;
		try {
			cs = new ANTLRFileStream(args[0]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		PascalFunLexer lexer = new PascalFunLexer(cs);
		TokenRewriteStream tokens = new TokenRewriteStream(lexer);
		PascalFunParser parser = new PascalFunParser(tokens);
		parser.setTreeAdaptor(pascalAdaptor);
		try {
			PascalFunParser.program_return result = parser.program();
			CommonTreeNodeStream nodes = new CommonTreeNodeStream(pascalAdaptor, result.getTree());
			nodes.setTokenStream(tokens);
			
			PascalFunTreeWalker treeWalker = new PascalFunTreeWalker(nodes, (Object) null); // Force the correct constructor
			
			PascalFunTreeWalker.program_return res = treeWalker.program();
			System.out.println(res.st.getTemplate());
		} catch (RecognitionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		System.out.println("end of analysis");
	}
}
