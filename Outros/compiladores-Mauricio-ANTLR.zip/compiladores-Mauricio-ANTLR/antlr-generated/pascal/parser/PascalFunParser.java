// $ANTLR 3.4 /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g 2012-12-05 09:43:52

package pascal.parser;

import pascal.parser.semantic.PascalTree;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.runtime.tree.*;


@SuppressWarnings({"all", "warnings", "unchecked"})
public class PascalFunParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ARRAY", "ASSIGN", "BEGIN", "BOOLEAN", "CALL", "COLON", "COMMA", "DIFFERENT", "DIGIT", "DO", "DOT", "ELSE", "END", "EQUALS", "FUNCTION", "FUNCTIONAL", "FUNCTIONAL_PARAM", "GET", "GT", "IDENT", "IF", "IMPLEMENTATION", "LEFT_BRACKET", "LEFT_PARENTESIS", "LET", "LETTER", "LT", "MINUS", "NOT", "NUMBER", "OF", "PARAM", "PLUS", "PROCEDURE", "PROGRAM", "RIGHT_BRACKET", "RIGHT_PARENTESIS", "SEMICOLON", "SLASH", "STM_LIST", "STRING", "THEN", "TIMES", "TWO_DOTS", "USES", "VAR", "WHILE", "WHITESPACE"
    };

    public static final int EOF=-1;
    public static final int ARRAY=4;
    public static final int ASSIGN=5;
    public static final int BEGIN=6;
    public static final int BOOLEAN=7;
    public static final int CALL=8;
    public static final int COLON=9;
    public static final int COMMA=10;
    public static final int DIFFERENT=11;
    public static final int DIGIT=12;
    public static final int DO=13;
    public static final int DOT=14;
    public static final int ELSE=15;
    public static final int END=16;
    public static final int EQUALS=17;
    public static final int FUNCTION=18;
    public static final int FUNCTIONAL=19;
    public static final int FUNCTIONAL_PARAM=20;
    public static final int GET=21;
    public static final int GT=22;
    public static final int IDENT=23;
    public static final int IF=24;
    public static final int IMPLEMENTATION=25;
    public static final int LEFT_BRACKET=26;
    public static final int LEFT_PARENTESIS=27;
    public static final int LET=28;
    public static final int LETTER=29;
    public static final int LT=30;
    public static final int MINUS=31;
    public static final int NOT=32;
    public static final int NUMBER=33;
    public static final int OF=34;
    public static final int PARAM=35;
    public static final int PLUS=36;
    public static final int PROCEDURE=37;
    public static final int PROGRAM=38;
    public static final int RIGHT_BRACKET=39;
    public static final int RIGHT_PARENTESIS=40;
    public static final int SEMICOLON=41;
    public static final int SLASH=42;
    public static final int STM_LIST=43;
    public static final int STRING=44;
    public static final int THEN=45;
    public static final int TIMES=46;
    public static final int TWO_DOTS=47;
    public static final int USES=48;
    public static final int VAR=49;
    public static final int WHILE=50;
    public static final int WHITESPACE=51;

    // delegates
    public Parser[] getDelegates() {
        return new Parser[] {};
    }

    // delegators


    public PascalFunParser(TokenStream input) {
        this(input, new RecognizerSharedState());
    }
    public PascalFunParser(TokenStream input, RecognizerSharedState state) {
        super(input, state);
    }

protected TreeAdaptor adaptor = new CommonTreeAdaptor();

public void setTreeAdaptor(TreeAdaptor adaptor) {
    this.adaptor = adaptor;
}
public TreeAdaptor getTreeAdaptor() {
    return adaptor;
}
    public String[] getTokenNames() { return PascalFunParser.tokenNames; }
    public String getGrammarFileName() { return "/home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g"; }


    public static class program_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "program"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:67:1: program : PROGRAM ^ IDENT SEMICOLON ! ( uses_decl )? ( implementation_block )? END ! DOT ! EOF ;
    public final PascalFunParser.program_return program() throws RecognitionException {
        PascalFunParser.program_return retval = new PascalFunParser.program_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token PROGRAM1=null;
        Token IDENT2=null;
        Token SEMICOLON3=null;
        Token END6=null;
        Token DOT7=null;
        Token EOF8=null;
        PascalFunParser.uses_decl_return uses_decl4 =null;

        PascalFunParser.implementation_block_return implementation_block5 =null;


        PascalTree PROGRAM1_tree=null;
        PascalTree IDENT2_tree=null;
        PascalTree SEMICOLON3_tree=null;
        PascalTree END6_tree=null;
        PascalTree DOT7_tree=null;
        PascalTree EOF8_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:68:3: ( PROGRAM ^ IDENT SEMICOLON ! ( uses_decl )? ( implementation_block )? END ! DOT ! EOF )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:69:3: PROGRAM ^ IDENT SEMICOLON ! ( uses_decl )? ( implementation_block )? END ! DOT ! EOF
            {
            root_0 = (PascalTree)adaptor.nil();


            PROGRAM1=(Token)match(input,PROGRAM,FOLLOW_PROGRAM_in_program363); 
            PROGRAM1_tree = 
            (PascalTree)adaptor.create(PROGRAM1)
            ;
            root_0 = (PascalTree)adaptor.becomeRoot(PROGRAM1_tree, root_0);


            IDENT2=(Token)match(input,IDENT,FOLLOW_IDENT_in_program366); 
            IDENT2_tree = 
            (PascalTree)adaptor.create(IDENT2)
            ;
            adaptor.addChild(root_0, IDENT2_tree);


            SEMICOLON3=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_program368); 

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:69:29: ( uses_decl )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==USES) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:69:29: uses_decl
                    {
                    pushFollow(FOLLOW_uses_decl_in_program371);
                    uses_decl4=uses_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, uses_decl4.getTree());

                    }
                    break;

            }


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:69:40: ( implementation_block )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==IMPLEMENTATION) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:69:40: implementation_block
                    {
                    pushFollow(FOLLOW_implementation_block_in_program374);
                    implementation_block5=implementation_block();

                    state._fsp--;

                    adaptor.addChild(root_0, implementation_block5.getTree());

                    }
                    break;

            }


            END6=(Token)match(input,END,FOLLOW_END_in_program377); 

            DOT7=(Token)match(input,DOT,FOLLOW_DOT_in_program380); 

            EOF8=(Token)match(input,EOF,FOLLOW_EOF_in_program383); 
            EOF8_tree = 
            (PascalTree)adaptor.create(EOF8)
            ;
            adaptor.addChild(root_0, EOF8_tree);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "program"


    public static class uses_decl_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "uses_decl"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:72:1: uses_decl : USES ^ IDENT ( COMMA ! IDENT )* SEMICOLON !;
    public final PascalFunParser.uses_decl_return uses_decl() throws RecognitionException {
        PascalFunParser.uses_decl_return retval = new PascalFunParser.uses_decl_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token USES9=null;
        Token IDENT10=null;
        Token COMMA11=null;
        Token IDENT12=null;
        Token SEMICOLON13=null;

        PascalTree USES9_tree=null;
        PascalTree IDENT10_tree=null;
        PascalTree COMMA11_tree=null;
        PascalTree IDENT12_tree=null;
        PascalTree SEMICOLON13_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:73:3: ( USES ^ IDENT ( COMMA ! IDENT )* SEMICOLON !)
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:74:3: USES ^ IDENT ( COMMA ! IDENT )* SEMICOLON !
            {
            root_0 = (PascalTree)adaptor.nil();


            USES9=(Token)match(input,USES,FOLLOW_USES_in_uses_decl398); 
            USES9_tree = 
            (PascalTree)adaptor.create(USES9)
            ;
            root_0 = (PascalTree)adaptor.becomeRoot(USES9_tree, root_0);


            IDENT10=(Token)match(input,IDENT,FOLLOW_IDENT_in_uses_decl401); 
            IDENT10_tree = 
            (PascalTree)adaptor.create(IDENT10)
            ;
            adaptor.addChild(root_0, IDENT10_tree);


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:74:15: ( COMMA ! IDENT )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==COMMA) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:74:16: COMMA ! IDENT
            	    {
            	    COMMA11=(Token)match(input,COMMA,FOLLOW_COMMA_in_uses_decl404); 

            	    IDENT12=(Token)match(input,IDENT,FOLLOW_IDENT_in_uses_decl407); 
            	    IDENT12_tree = 
            	    (PascalTree)adaptor.create(IDENT12)
            	    ;
            	    adaptor.addChild(root_0, IDENT12_tree);


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            SEMICOLON13=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_uses_decl411); 

            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "uses_decl"


    public static class var_decl_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "var_decl"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:77:1: var_decl : VAR ^ ( IDENT COLON ! type_decl SEMICOLON !)+ ;
    public final PascalFunParser.var_decl_return var_decl() throws RecognitionException {
        PascalFunParser.var_decl_return retval = new PascalFunParser.var_decl_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token VAR14=null;
        Token IDENT15=null;
        Token COLON16=null;
        Token SEMICOLON18=null;
        PascalFunParser.type_decl_return type_decl17 =null;


        PascalTree VAR14_tree=null;
        PascalTree IDENT15_tree=null;
        PascalTree COLON16_tree=null;
        PascalTree SEMICOLON18_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:78:3: ( VAR ^ ( IDENT COLON ! type_decl SEMICOLON !)+ )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:79:3: VAR ^ ( IDENT COLON ! type_decl SEMICOLON !)+
            {
            root_0 = (PascalTree)adaptor.nil();


            VAR14=(Token)match(input,VAR,FOLLOW_VAR_in_var_decl427); 
            VAR14_tree = 
            (PascalTree)adaptor.create(VAR14)
            ;
            root_0 = (PascalTree)adaptor.becomeRoot(VAR14_tree, root_0);


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:79:8: ( IDENT COLON ! type_decl SEMICOLON !)+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==IDENT) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:79:9: IDENT COLON ! type_decl SEMICOLON !
            	    {
            	    IDENT15=(Token)match(input,IDENT,FOLLOW_IDENT_in_var_decl431); 
            	    IDENT15_tree = 
            	    (PascalTree)adaptor.create(IDENT15)
            	    ;
            	    adaptor.addChild(root_0, IDENT15_tree);


            	    COLON16=(Token)match(input,COLON,FOLLOW_COLON_in_var_decl433); 

            	    pushFollow(FOLLOW_type_decl_in_var_decl436);
            	    type_decl17=type_decl();

            	    state._fsp--;

            	    adaptor.addChild(root_0, type_decl17.getTree());

            	    SEMICOLON18=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_var_decl438); 

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "var_decl"


    public static class param_decl_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "param_decl"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:82:1: param_decl : a= IDENT COLON b= type_decl ( COMMA c= IDENT COLON d= type_decl )* -> ^( PARAM $a $b ( $c $d)* ) ;
    public final PascalFunParser.param_decl_return param_decl() throws RecognitionException {
        PascalFunParser.param_decl_return retval = new PascalFunParser.param_decl_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token a=null;
        Token c=null;
        Token COLON19=null;
        Token COMMA20=null;
        Token COLON21=null;
        PascalFunParser.type_decl_return b =null;

        PascalFunParser.type_decl_return d =null;


        PascalTree a_tree=null;
        PascalTree c_tree=null;
        PascalTree COLON19_tree=null;
        PascalTree COMMA20_tree=null;
        PascalTree COLON21_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_type_decl=new RewriteRuleSubtreeStream(adaptor,"rule type_decl");
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:83:3: (a= IDENT COLON b= type_decl ( COMMA c= IDENT COLON d= type_decl )* -> ^( PARAM $a $b ( $c $d)* ) )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:84:3: a= IDENT COLON b= type_decl ( COMMA c= IDENT COLON d= type_decl )*
            {
            a=(Token)match(input,IDENT,FOLLOW_IDENT_in_param_decl458);  
            stream_IDENT.add(a);


            COLON19=(Token)match(input,COLON,FOLLOW_COLON_in_param_decl460);  
            stream_COLON.add(COLON19);


            pushFollow(FOLLOW_type_decl_in_param_decl464);
            b=type_decl();

            state._fsp--;

            stream_type_decl.add(b.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:84:29: ( COMMA c= IDENT COLON d= type_decl )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==COMMA) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:84:30: COMMA c= IDENT COLON d= type_decl
            	    {
            	    COMMA20=(Token)match(input,COMMA,FOLLOW_COMMA_in_param_decl467);  
            	    stream_COMMA.add(COMMA20);


            	    c=(Token)match(input,IDENT,FOLLOW_IDENT_in_param_decl471);  
            	    stream_IDENT.add(c);


            	    COLON21=(Token)match(input,COLON,FOLLOW_COLON_in_param_decl473);  
            	    stream_COLON.add(COLON21);


            	    pushFollow(FOLLOW_type_decl_in_param_decl477);
            	    d=type_decl();

            	    state._fsp--;

            	    stream_type_decl.add(d.getTree());

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            // AST REWRITE
            // elements: b, a, c, d
            // token labels: c, a
            // rule labels: retval, d, b
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_c=new RewriteRuleTokenStream(adaptor,"token c",c);
            RewriteRuleTokenStream stream_a=new RewriteRuleTokenStream(adaptor,"token a",a);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_d=new RewriteRuleSubtreeStream(adaptor,"rule d",d!=null?d.tree:null);
            RewriteRuleSubtreeStream stream_b=new RewriteRuleSubtreeStream(adaptor,"rule b",b!=null?b.tree:null);

            root_0 = (PascalTree)adaptor.nil();
            // 84:64: -> ^( PARAM $a $b ( $c $d)* )
            {
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:84:67: ^( PARAM $a $b ( $c $d)* )
                {
                PascalTree root_1 = (PascalTree)adaptor.nil();
                root_1 = (PascalTree)adaptor.becomeRoot(
                (PascalTree)adaptor.create(PARAM, "PARAM")
                , root_1);

                adaptor.addChild(root_1, stream_a.nextNode());

                adaptor.addChild(root_1, stream_b.nextTree());

                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:84:81: ( $c $d)*
                while ( stream_c.hasNext()||stream_d.hasNext() ) {
                    adaptor.addChild(root_1, stream_c.nextNode());

                    adaptor.addChild(root_1, stream_d.nextTree());

                }
                stream_c.reset();
                stream_d.reset();

                adaptor.addChild(root_0, root_1);
                }

            }


            retval.tree = root_0;

            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "param_decl"


    public static class type_decl_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "type_decl"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:87:1: type_decl : ( IDENT | ARRAY ^ ( LEFT_BRACKET ! NUMBER TWO_DOTS ! NUMBER RIGHT_BRACKET !)? OF ! type_decl );
    public final PascalFunParser.type_decl_return type_decl() throws RecognitionException {
        PascalFunParser.type_decl_return retval = new PascalFunParser.type_decl_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token IDENT22=null;
        Token ARRAY23=null;
        Token LEFT_BRACKET24=null;
        Token NUMBER25=null;
        Token TWO_DOTS26=null;
        Token NUMBER27=null;
        Token RIGHT_BRACKET28=null;
        Token OF29=null;
        PascalFunParser.type_decl_return type_decl30 =null;


        PascalTree IDENT22_tree=null;
        PascalTree ARRAY23_tree=null;
        PascalTree LEFT_BRACKET24_tree=null;
        PascalTree NUMBER25_tree=null;
        PascalTree TWO_DOTS26_tree=null;
        PascalTree NUMBER27_tree=null;
        PascalTree RIGHT_BRACKET28_tree=null;
        PascalTree OF29_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:88:3: ( IDENT | ARRAY ^ ( LEFT_BRACKET ! NUMBER TWO_DOTS ! NUMBER RIGHT_BRACKET !)? OF ! type_decl )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==IDENT) ) {
                alt7=1;
            }
            else if ( (LA7_0==ARRAY) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;

            }
            switch (alt7) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:89:3: IDENT
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    IDENT22=(Token)match(input,IDENT,FOLLOW_IDENT_in_type_decl515); 
                    IDENT22_tree = 
                    (PascalTree)adaptor.create(IDENT22)
                    ;
                    adaptor.addChild(root_0, IDENT22_tree);


                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:90:5: ARRAY ^ ( LEFT_BRACKET ! NUMBER TWO_DOTS ! NUMBER RIGHT_BRACKET !)? OF ! type_decl
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    ARRAY23=(Token)match(input,ARRAY,FOLLOW_ARRAY_in_type_decl521); 
                    ARRAY23_tree = 
                    (PascalTree)adaptor.create(ARRAY23)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(ARRAY23_tree, root_0);


                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:90:12: ( LEFT_BRACKET ! NUMBER TWO_DOTS ! NUMBER RIGHT_BRACKET !)?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==LEFT_BRACKET) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:90:13: LEFT_BRACKET ! NUMBER TWO_DOTS ! NUMBER RIGHT_BRACKET !
                            {
                            LEFT_BRACKET24=(Token)match(input,LEFT_BRACKET,FOLLOW_LEFT_BRACKET_in_type_decl525); 

                            NUMBER25=(Token)match(input,NUMBER,FOLLOW_NUMBER_in_type_decl528); 
                            NUMBER25_tree = 
                            (PascalTree)adaptor.create(NUMBER25)
                            ;
                            adaptor.addChild(root_0, NUMBER25_tree);


                            TWO_DOTS26=(Token)match(input,TWO_DOTS,FOLLOW_TWO_DOTS_in_type_decl530); 

                            NUMBER27=(Token)match(input,NUMBER,FOLLOW_NUMBER_in_type_decl533); 
                            NUMBER27_tree = 
                            (PascalTree)adaptor.create(NUMBER27)
                            ;
                            adaptor.addChild(root_0, NUMBER27_tree);


                            RIGHT_BRACKET28=(Token)match(input,RIGHT_BRACKET,FOLLOW_RIGHT_BRACKET_in_type_decl535); 

                            }
                            break;

                    }


                    OF29=(Token)match(input,OF,FOLLOW_OF_in_type_decl540); 

                    pushFollow(FOLLOW_type_decl_in_type_decl543);
                    type_decl30=type_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, type_decl30.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "type_decl"


    public static class implementation_block_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "implementation_block"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:93:1: implementation_block : IMPLEMENTATION ^ ( impl_member_decl )* ;
    public final PascalFunParser.implementation_block_return implementation_block() throws RecognitionException {
        PascalFunParser.implementation_block_return retval = new PascalFunParser.implementation_block_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token IMPLEMENTATION31=null;
        PascalFunParser.impl_member_decl_return impl_member_decl32 =null;


        PascalTree IMPLEMENTATION31_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:94:3: ( IMPLEMENTATION ^ ( impl_member_decl )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:95:3: IMPLEMENTATION ^ ( impl_member_decl )*
            {
            root_0 = (PascalTree)adaptor.nil();


            IMPLEMENTATION31=(Token)match(input,IMPLEMENTATION,FOLLOW_IMPLEMENTATION_in_implementation_block558); 
            IMPLEMENTATION31_tree = 
            (PascalTree)adaptor.create(IMPLEMENTATION31)
            ;
            root_0 = (PascalTree)adaptor.becomeRoot(IMPLEMENTATION31_tree, root_0);


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:96:3: ( impl_member_decl )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0 >= FUNCTION && LA8_0 <= FUNCTIONAL)||LA8_0==PROCEDURE||LA8_0==VAR) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:96:3: impl_member_decl
            	    {
            	    pushFollow(FOLLOW_impl_member_decl_in_implementation_block563);
            	    impl_member_decl32=impl_member_decl();

            	    state._fsp--;

            	    adaptor.addChild(root_0, impl_member_decl32.getTree());

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "implementation_block"


    public static class impl_member_decl_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "impl_member_decl"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:99:1: impl_member_decl : ( var_decl | FUNCTION ^ IDENT ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)? COLON ! IDENT SEMICOLON ! ( var_decl )? method_stm_list | PROCEDURE ^ IDENT ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)? SEMICOLON ! ( var_decl )? method_stm_list | FUNCTIONAL ^ IDENT LEFT_PARENTESIS ! functional_param_decl RIGHT_PARENTESIS ! COLON ! IDENT EQUALS ! expr SEMICOLON !);
    public final PascalFunParser.impl_member_decl_return impl_member_decl() throws RecognitionException {
        PascalFunParser.impl_member_decl_return retval = new PascalFunParser.impl_member_decl_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token FUNCTION34=null;
        Token IDENT35=null;
        Token LEFT_PARENTESIS36=null;
        Token RIGHT_PARENTESIS38=null;
        Token COLON39=null;
        Token IDENT40=null;
        Token SEMICOLON41=null;
        Token PROCEDURE44=null;
        Token IDENT45=null;
        Token LEFT_PARENTESIS46=null;
        Token RIGHT_PARENTESIS48=null;
        Token SEMICOLON49=null;
        Token FUNCTIONAL52=null;
        Token IDENT53=null;
        Token LEFT_PARENTESIS54=null;
        Token RIGHT_PARENTESIS56=null;
        Token COLON57=null;
        Token IDENT58=null;
        Token EQUALS59=null;
        Token SEMICOLON61=null;
        PascalFunParser.var_decl_return var_decl33 =null;

        PascalFunParser.param_decl_return param_decl37 =null;

        PascalFunParser.var_decl_return var_decl42 =null;

        PascalFunParser.method_stm_list_return method_stm_list43 =null;

        PascalFunParser.param_decl_return param_decl47 =null;

        PascalFunParser.var_decl_return var_decl50 =null;

        PascalFunParser.method_stm_list_return method_stm_list51 =null;

        PascalFunParser.functional_param_decl_return functional_param_decl55 =null;

        PascalFunParser.expr_return expr60 =null;


        PascalTree FUNCTION34_tree=null;
        PascalTree IDENT35_tree=null;
        PascalTree LEFT_PARENTESIS36_tree=null;
        PascalTree RIGHT_PARENTESIS38_tree=null;
        PascalTree COLON39_tree=null;
        PascalTree IDENT40_tree=null;
        PascalTree SEMICOLON41_tree=null;
        PascalTree PROCEDURE44_tree=null;
        PascalTree IDENT45_tree=null;
        PascalTree LEFT_PARENTESIS46_tree=null;
        PascalTree RIGHT_PARENTESIS48_tree=null;
        PascalTree SEMICOLON49_tree=null;
        PascalTree FUNCTIONAL52_tree=null;
        PascalTree IDENT53_tree=null;
        PascalTree LEFT_PARENTESIS54_tree=null;
        PascalTree RIGHT_PARENTESIS56_tree=null;
        PascalTree COLON57_tree=null;
        PascalTree IDENT58_tree=null;
        PascalTree EQUALS59_tree=null;
        PascalTree SEMICOLON61_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:100:3: ( var_decl | FUNCTION ^ IDENT ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)? COLON ! IDENT SEMICOLON ! ( var_decl )? method_stm_list | PROCEDURE ^ IDENT ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)? SEMICOLON ! ( var_decl )? method_stm_list | FUNCTIONAL ^ IDENT LEFT_PARENTESIS ! functional_param_decl RIGHT_PARENTESIS ! COLON ! IDENT EQUALS ! expr SEMICOLON !)
            int alt13=4;
            switch ( input.LA(1) ) {
            case VAR:
                {
                alt13=1;
                }
                break;
            case FUNCTION:
                {
                alt13=2;
                }
                break;
            case PROCEDURE:
                {
                alt13=3;
                }
                break;
            case FUNCTIONAL:
                {
                alt13=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;

            }

            switch (alt13) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:101:3: var_decl
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    pushFollow(FOLLOW_var_decl_in_impl_member_decl581);
                    var_decl33=var_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, var_decl33.getTree());

                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:102:5: FUNCTION ^ IDENT ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)? COLON ! IDENT SEMICOLON ! ( var_decl )? method_stm_list
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    FUNCTION34=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_impl_member_decl587); 
                    FUNCTION34_tree = 
                    (PascalTree)adaptor.create(FUNCTION34)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(FUNCTION34_tree, root_0);


                    IDENT35=(Token)match(input,IDENT,FOLLOW_IDENT_in_impl_member_decl590); 
                    IDENT35_tree = 
                    (PascalTree)adaptor.create(IDENT35)
                    ;
                    adaptor.addChild(root_0, IDENT35_tree);


                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:102:21: ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==LEFT_PARENTESIS) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:102:22: LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !
                            {
                            LEFT_PARENTESIS36=(Token)match(input,LEFT_PARENTESIS,FOLLOW_LEFT_PARENTESIS_in_impl_member_decl593); 

                            pushFollow(FOLLOW_param_decl_in_impl_member_decl596);
                            param_decl37=param_decl();

                            state._fsp--;

                            adaptor.addChild(root_0, param_decl37.getTree());

                            RIGHT_PARENTESIS38=(Token)match(input,RIGHT_PARENTESIS,FOLLOW_RIGHT_PARENTESIS_in_impl_member_decl598); 

                            }
                            break;

                    }


                    COLON39=(Token)match(input,COLON,FOLLOW_COLON_in_impl_member_decl603); 

                    IDENT40=(Token)match(input,IDENT,FOLLOW_IDENT_in_impl_member_decl606); 
                    IDENT40_tree = 
                    (PascalTree)adaptor.create(IDENT40)
                    ;
                    adaptor.addChild(root_0, IDENT40_tree);


                    SEMICOLON41=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_impl_member_decl608); 

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:102:94: ( var_decl )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==VAR) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:102:94: var_decl
                            {
                            pushFollow(FOLLOW_var_decl_in_impl_member_decl611);
                            var_decl42=var_decl();

                            state._fsp--;

                            adaptor.addChild(root_0, var_decl42.getTree());

                            }
                            break;

                    }


                    pushFollow(FOLLOW_method_stm_list_in_impl_member_decl614);
                    method_stm_list43=method_stm_list();

                    state._fsp--;

                    adaptor.addChild(root_0, method_stm_list43.getTree());

                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:103:5: PROCEDURE ^ IDENT ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)? SEMICOLON ! ( var_decl )? method_stm_list
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    PROCEDURE44=(Token)match(input,PROCEDURE,FOLLOW_PROCEDURE_in_impl_member_decl621); 
                    PROCEDURE44_tree = 
                    (PascalTree)adaptor.create(PROCEDURE44)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(PROCEDURE44_tree, root_0);


                    IDENT45=(Token)match(input,IDENT,FOLLOW_IDENT_in_impl_member_decl624); 
                    IDENT45_tree = 
                    (PascalTree)adaptor.create(IDENT45)
                    ;
                    adaptor.addChild(root_0, IDENT45_tree);


                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:103:22: ( LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !)?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==LEFT_PARENTESIS) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:103:23: LEFT_PARENTESIS ! param_decl RIGHT_PARENTESIS !
                            {
                            LEFT_PARENTESIS46=(Token)match(input,LEFT_PARENTESIS,FOLLOW_LEFT_PARENTESIS_in_impl_member_decl627); 

                            pushFollow(FOLLOW_param_decl_in_impl_member_decl630);
                            param_decl47=param_decl();

                            state._fsp--;

                            adaptor.addChild(root_0, param_decl47.getTree());

                            RIGHT_PARENTESIS48=(Token)match(input,RIGHT_PARENTESIS,FOLLOW_RIGHT_PARENTESIS_in_impl_member_decl632); 

                            }
                            break;

                    }


                    SEMICOLON49=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_impl_member_decl637); 

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:103:82: ( var_decl )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==VAR) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:103:82: var_decl
                            {
                            pushFollow(FOLLOW_var_decl_in_impl_member_decl640);
                            var_decl50=var_decl();

                            state._fsp--;

                            adaptor.addChild(root_0, var_decl50.getTree());

                            }
                            break;

                    }


                    pushFollow(FOLLOW_method_stm_list_in_impl_member_decl643);
                    method_stm_list51=method_stm_list();

                    state._fsp--;

                    adaptor.addChild(root_0, method_stm_list51.getTree());

                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:104:5: FUNCTIONAL ^ IDENT LEFT_PARENTESIS ! functional_param_decl RIGHT_PARENTESIS ! COLON ! IDENT EQUALS ! expr SEMICOLON !
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    FUNCTIONAL52=(Token)match(input,FUNCTIONAL,FOLLOW_FUNCTIONAL_in_impl_member_decl649); 
                    FUNCTIONAL52_tree = 
                    (PascalTree)adaptor.create(FUNCTIONAL52)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(FUNCTIONAL52_tree, root_0);


                    IDENT53=(Token)match(input,IDENT,FOLLOW_IDENT_in_impl_member_decl652); 
                    IDENT53_tree = 
                    (PascalTree)adaptor.create(IDENT53)
                    ;
                    adaptor.addChild(root_0, IDENT53_tree);


                    LEFT_PARENTESIS54=(Token)match(input,LEFT_PARENTESIS,FOLLOW_LEFT_PARENTESIS_in_impl_member_decl654); 

                    pushFollow(FOLLOW_functional_param_decl_in_impl_member_decl657);
                    functional_param_decl55=functional_param_decl();

                    state._fsp--;

                    adaptor.addChild(root_0, functional_param_decl55.getTree());

                    RIGHT_PARENTESIS56=(Token)match(input,RIGHT_PARENTESIS,FOLLOW_RIGHT_PARENTESIS_in_impl_member_decl659); 

                    COLON57=(Token)match(input,COLON,FOLLOW_COLON_in_impl_member_decl662); 

                    IDENT58=(Token)match(input,IDENT,FOLLOW_IDENT_in_impl_member_decl665); 
                    IDENT58_tree = 
                    (PascalTree)adaptor.create(IDENT58)
                    ;
                    adaptor.addChild(root_0, IDENT58_tree);


                    EQUALS59=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_impl_member_decl667); 

                    pushFollow(FOLLOW_expr_in_impl_member_decl670);
                    expr60=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr60.getTree());

                    SEMICOLON61=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_impl_member_decl672); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "impl_member_decl"


    public static class functional_param_decl_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "functional_param_decl"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:107:1: functional_param_decl : (a= expr ( COLON b= type_decl )? ) ( COMMA c+= expr ( COLON d+= type_decl )? )* -> ^( FUNCTIONAL_PARAM $a ( $b)? ( $c ( $d)? )* ) ;
    public final PascalFunParser.functional_param_decl_return functional_param_decl() throws RecognitionException {
        PascalFunParser.functional_param_decl_return retval = new PascalFunParser.functional_param_decl_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token COLON62=null;
        Token COMMA63=null;
        Token COLON64=null;
        List list_c=null;
        List list_d=null;
        PascalFunParser.expr_return a =null;

        PascalFunParser.type_decl_return b =null;

        RuleReturnScope c = null;
        RuleReturnScope d = null;
        PascalTree COLON62_tree=null;
        PascalTree COMMA63_tree=null;
        PascalTree COLON64_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_type_decl=new RewriteRuleSubtreeStream(adaptor,"rule type_decl");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:108:3: ( (a= expr ( COLON b= type_decl )? ) ( COMMA c+= expr ( COLON d+= type_decl )? )* -> ^( FUNCTIONAL_PARAM $a ( $b)? ( $c ( $d)? )* ) )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:3: (a= expr ( COLON b= type_decl )? ) ( COMMA c+= expr ( COLON d+= type_decl )? )*
            {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:3: (a= expr ( COLON b= type_decl )? )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:4: a= expr ( COLON b= type_decl )?
            {
            pushFollow(FOLLOW_expr_in_functional_param_decl693);
            a=expr();

            state._fsp--;

            stream_expr.add(a.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:11: ( COLON b= type_decl )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==COLON) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:12: COLON b= type_decl
                    {
                    COLON62=(Token)match(input,COLON,FOLLOW_COLON_in_functional_param_decl696);  
                    stream_COLON.add(COLON62);


                    pushFollow(FOLLOW_type_decl_in_functional_param_decl700);
                    b=type_decl();

                    state._fsp--;

                    stream_type_decl.add(b.getTree());

                    }
                    break;

            }


            }


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:34: ( COMMA c+= expr ( COLON d+= type_decl )? )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==COMMA) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:35: COMMA c+= expr ( COLON d+= type_decl )?
            	    {
            	    COMMA63=(Token)match(input,COMMA,FOLLOW_COMMA_in_functional_param_decl707);  
            	    stream_COMMA.add(COMMA63);


            	    pushFollow(FOLLOW_expr_in_functional_param_decl711);
            	    c=expr();

            	    state._fsp--;

            	    stream_expr.add(c.getTree());
            	    if (list_c==null) list_c=new ArrayList();
            	    list_c.add(c.getTree());


            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:49: ( COLON d+= type_decl )?
            	    int alt15=2;
            	    int LA15_0 = input.LA(1);

            	    if ( (LA15_0==COLON) ) {
            	        alt15=1;
            	    }
            	    switch (alt15) {
            	        case 1 :
            	            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:50: COLON d+= type_decl
            	            {
            	            COLON64=(Token)match(input,COLON,FOLLOW_COLON_in_functional_param_decl714);  
            	            stream_COLON.add(COLON64);


            	            pushFollow(FOLLOW_type_decl_in_functional_param_decl718);
            	            d=type_decl();

            	            state._fsp--;

            	            stream_type_decl.add(d.getTree());
            	            if (list_d==null) list_d=new ArrayList();
            	            list_d.add(d.getTree());


            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            // AST REWRITE
            // elements: a, c, d, b
            // token labels: 
            // rule labels: retval, b, a
            // token list labels: 
            // rule list labels: d, c
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_b=new RewriteRuleSubtreeStream(adaptor,"rule b",b!=null?b.tree:null);
            RewriteRuleSubtreeStream stream_a=new RewriteRuleSubtreeStream(adaptor,"rule a",a!=null?a.tree:null);
            RewriteRuleSubtreeStream stream_d=new RewriteRuleSubtreeStream(adaptor,"token d",list_d);
            RewriteRuleSubtreeStream stream_c=new RewriteRuleSubtreeStream(adaptor,"token c",list_c);
            root_0 = (PascalTree)adaptor.nil();
            // 109:73: -> ^( FUNCTIONAL_PARAM $a ( $b)? ( $c ( $d)? )* )
            {
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:76: ^( FUNCTIONAL_PARAM $a ( $b)? ( $c ( $d)? )* )
                {
                PascalTree root_1 = (PascalTree)adaptor.nil();
                root_1 = (PascalTree)adaptor.becomeRoot(
                (PascalTree)adaptor.create(FUNCTIONAL_PARAM, "FUNCTIONAL_PARAM")
                , root_1);

                adaptor.addChild(root_1, stream_a.nextTree());

                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:99: ( $b)?
                if ( stream_b.hasNext() ) {
                    adaptor.addChild(root_1, stream_b.nextTree());

                }
                stream_b.reset();

                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:102: ( $c ( $d)? )*
                while ( stream_c.hasNext() ) {
                    adaptor.addChild(root_1, stream_c.nextTree());

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:109:107: ( $d)?
                    if ( stream_d.hasNext() ) {
                        adaptor.addChild(root_1, stream_d.nextTree());

                    }
                    stream_d.reset();

                }
                stream_c.reset();

                adaptor.addChild(root_0, root_1);
                }

            }


            retval.tree = root_0;

            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "functional_param_decl"


    public static class stm_list_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "stm_list"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:112:1: stm_list : ( BEGIN (a+= stm )* END SEMICOLON -> ^( STM_LIST ( $a)* ) | stm );
    public final PascalFunParser.stm_list_return stm_list() throws RecognitionException {
        PascalFunParser.stm_list_return retval = new PascalFunParser.stm_list_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token BEGIN65=null;
        Token END66=null;
        Token SEMICOLON67=null;
        List list_a=null;
        PascalFunParser.stm_return stm68 =null;

        RuleReturnScope a = null;
        PascalTree BEGIN65_tree=null;
        PascalTree END66_tree=null;
        PascalTree SEMICOLON67_tree=null;
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleTokenStream stream_END=new RewriteRuleTokenStream(adaptor,"token END");
        RewriteRuleTokenStream stream_BEGIN=new RewriteRuleTokenStream(adaptor,"token BEGIN");
        RewriteRuleSubtreeStream stream_stm=new RewriteRuleSubtreeStream(adaptor,"rule stm");
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:113:3: ( BEGIN (a+= stm )* END SEMICOLON -> ^( STM_LIST ( $a)* ) | stm )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==BEGIN) ) {
                alt18=1;
            }
            else if ( (LA18_0==BOOLEAN||(LA18_0 >= IDENT && LA18_0 <= IF)||LA18_0==LEFT_PARENTESIS||(LA18_0 >= MINUS && LA18_0 <= NUMBER)||LA18_0==STRING||LA18_0==WHILE) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;

            }
            switch (alt18) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:114:3: BEGIN (a+= stm )* END SEMICOLON
                    {
                    BEGIN65=(Token)match(input,BEGIN,FOLLOW_BEGIN_in_stm_list762);  
                    stream_BEGIN.add(BEGIN65);


                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:114:9: (a+= stm )*
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0==BOOLEAN||(LA17_0 >= IDENT && LA17_0 <= IF)||LA17_0==LEFT_PARENTESIS||(LA17_0 >= MINUS && LA17_0 <= NUMBER)||LA17_0==STRING||LA17_0==WHILE) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:114:10: a+= stm
                    	    {
                    	    pushFollow(FOLLOW_stm_in_stm_list767);
                    	    a=stm();

                    	    state._fsp--;

                    	    stream_stm.add(a.getTree());
                    	    if (list_a==null) list_a=new ArrayList();
                    	    list_a.add(a.getTree());


                    	    }
                    	    break;

                    	default :
                    	    break loop17;
                        }
                    } while (true);


                    END66=(Token)match(input,END,FOLLOW_END_in_stm_list771);  
                    stream_END.add(END66);


                    SEMICOLON67=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_stm_list773);  
                    stream_SEMICOLON.add(SEMICOLON67);


                    // AST REWRITE
                    // elements: a
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: a
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_a=new RewriteRuleSubtreeStream(adaptor,"token a",list_a);
                    root_0 = (PascalTree)adaptor.nil();
                    // 114:33: -> ^( STM_LIST ( $a)* )
                    {
                        // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:114:36: ^( STM_LIST ( $a)* )
                        {
                        PascalTree root_1 = (PascalTree)adaptor.nil();
                        root_1 = (PascalTree)adaptor.becomeRoot(
                        (PascalTree)adaptor.create(STM_LIST, "STM_LIST")
                        , root_1);

                        // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:114:48: ( $a)*
                        while ( stream_a.hasNext() ) {
                            adaptor.addChild(root_1, stream_a.nextTree());

                        }
                        stream_a.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }


                    retval.tree = root_0;

                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:115:5: stm
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    pushFollow(FOLLOW_stm_in_stm_list789);
                    stm68=stm();

                    state._fsp--;

                    adaptor.addChild(root_0, stm68.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "stm_list"


    public static class method_stm_list_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "method_stm_list"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:118:1: method_stm_list : BEGIN (a+= stm )* END SEMICOLON -> ^( STM_LIST ( $a)* ) ;
    public final PascalFunParser.method_stm_list_return method_stm_list() throws RecognitionException {
        PascalFunParser.method_stm_list_return retval = new PascalFunParser.method_stm_list_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token BEGIN69=null;
        Token END70=null;
        Token SEMICOLON71=null;
        List list_a=null;
        RuleReturnScope a = null;
        PascalTree BEGIN69_tree=null;
        PascalTree END70_tree=null;
        PascalTree SEMICOLON71_tree=null;
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleTokenStream stream_END=new RewriteRuleTokenStream(adaptor,"token END");
        RewriteRuleTokenStream stream_BEGIN=new RewriteRuleTokenStream(adaptor,"token BEGIN");
        RewriteRuleSubtreeStream stream_stm=new RewriteRuleSubtreeStream(adaptor,"rule stm");
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:119:3: ( BEGIN (a+= stm )* END SEMICOLON -> ^( STM_LIST ( $a)* ) )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:120:3: BEGIN (a+= stm )* END SEMICOLON
            {
            BEGIN69=(Token)match(input,BEGIN,FOLLOW_BEGIN_in_method_stm_list806);  
            stream_BEGIN.add(BEGIN69);


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:120:9: (a+= stm )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==BOOLEAN||(LA19_0 >= IDENT && LA19_0 <= IF)||LA19_0==LEFT_PARENTESIS||(LA19_0 >= MINUS && LA19_0 <= NUMBER)||LA19_0==STRING||LA19_0==WHILE) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:120:10: a+= stm
            	    {
            	    pushFollow(FOLLOW_stm_in_method_stm_list811);
            	    a=stm();

            	    state._fsp--;

            	    stream_stm.add(a.getTree());
            	    if (list_a==null) list_a=new ArrayList();
            	    list_a.add(a.getTree());


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);


            END70=(Token)match(input,END,FOLLOW_END_in_method_stm_list815);  
            stream_END.add(END70);


            SEMICOLON71=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_method_stm_list817);  
            stream_SEMICOLON.add(SEMICOLON71);


            // AST REWRITE
            // elements: a
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: a
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_a=new RewriteRuleSubtreeStream(adaptor,"token a",list_a);
            root_0 = (PascalTree)adaptor.nil();
            // 120:33: -> ^( STM_LIST ( $a)* )
            {
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:120:36: ^( STM_LIST ( $a)* )
                {
                PascalTree root_1 = (PascalTree)adaptor.nil();
                root_1 = (PascalTree)adaptor.becomeRoot(
                (PascalTree)adaptor.create(STM_LIST, "STM_LIST")
                , root_1);

                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:120:47: ( $a)*
                while ( stream_a.hasNext() ) {
                    adaptor.addChild(root_1, stream_a.nextTree());

                }
                stream_a.reset();

                adaptor.addChild(root_0, root_1);
                }

            }


            retval.tree = root_0;

            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "method_stm_list"


    public static class stm_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "stm"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:123:1: stm : ( if_stm | while_stm | expr SEMICOLON !);
    public final PascalFunParser.stm_return stm() throws RecognitionException {
        PascalFunParser.stm_return retval = new PascalFunParser.stm_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token SEMICOLON75=null;
        PascalFunParser.if_stm_return if_stm72 =null;

        PascalFunParser.while_stm_return while_stm73 =null;

        PascalFunParser.expr_return expr74 =null;


        PascalTree SEMICOLON75_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:124:3: ( if_stm | while_stm | expr SEMICOLON !)
            int alt20=3;
            switch ( input.LA(1) ) {
            case IF:
                {
                alt20=1;
                }
                break;
            case WHILE:
                {
                alt20=2;
                }
                break;
            case BOOLEAN:
            case IDENT:
            case LEFT_PARENTESIS:
            case MINUS:
            case NOT:
            case NUMBER:
            case STRING:
                {
                alt20=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;

            }

            switch (alt20) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:125:3: if_stm
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    pushFollow(FOLLOW_if_stm_in_stm846);
                    if_stm72=if_stm();

                    state._fsp--;

                    adaptor.addChild(root_0, if_stm72.getTree());

                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:126:5: while_stm
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    pushFollow(FOLLOW_while_stm_in_stm852);
                    while_stm73=while_stm();

                    state._fsp--;

                    adaptor.addChild(root_0, while_stm73.getTree());

                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:127:5: expr SEMICOLON !
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    pushFollow(FOLLOW_expr_in_stm858);
                    expr74=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr74.getTree());

                    SEMICOLON75=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_stm860); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "stm"


    public static class if_stm_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "if_stm"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:130:1: if_stm : IF ^ expr THEN ! stm_list ( ELSE stm_list )? ;
    public final PascalFunParser.if_stm_return if_stm() throws RecognitionException {
        PascalFunParser.if_stm_return retval = new PascalFunParser.if_stm_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token IF76=null;
        Token THEN78=null;
        Token ELSE80=null;
        PascalFunParser.expr_return expr77 =null;

        PascalFunParser.stm_list_return stm_list79 =null;

        PascalFunParser.stm_list_return stm_list81 =null;


        PascalTree IF76_tree=null;
        PascalTree THEN78_tree=null;
        PascalTree ELSE80_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:131:3: ( IF ^ expr THEN ! stm_list ( ELSE stm_list )? )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:132:3: IF ^ expr THEN ! stm_list ( ELSE stm_list )?
            {
            root_0 = (PascalTree)adaptor.nil();


            IF76=(Token)match(input,IF,FOLLOW_IF_in_if_stm878); 
            IF76_tree = 
            (PascalTree)adaptor.create(IF76)
            ;
            root_0 = (PascalTree)adaptor.becomeRoot(IF76_tree, root_0);


            pushFollow(FOLLOW_expr_in_if_stm881);
            expr77=expr();

            state._fsp--;

            adaptor.addChild(root_0, expr77.getTree());

            THEN78=(Token)match(input,THEN,FOLLOW_THEN_in_if_stm883); 

            pushFollow(FOLLOW_stm_list_in_if_stm886);
            stm_list79=stm_list();

            state._fsp--;

            adaptor.addChild(root_0, stm_list79.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:132:27: ( ELSE stm_list )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==ELSE) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:132:28: ELSE stm_list
                    {
                    ELSE80=(Token)match(input,ELSE,FOLLOW_ELSE_in_if_stm889); 
                    ELSE80_tree = 
                    (PascalTree)adaptor.create(ELSE80)
                    ;
                    adaptor.addChild(root_0, ELSE80_tree);


                    pushFollow(FOLLOW_stm_list_in_if_stm891);
                    stm_list81=stm_list();

                    state._fsp--;

                    adaptor.addChild(root_0, stm_list81.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "if_stm"


    public static class while_stm_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "while_stm"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:135:1: while_stm : WHILE ^ expr DO ! stm_list ;
    public final PascalFunParser.while_stm_return while_stm() throws RecognitionException {
        PascalFunParser.while_stm_return retval = new PascalFunParser.while_stm_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token WHILE82=null;
        Token DO84=null;
        PascalFunParser.expr_return expr83 =null;

        PascalFunParser.stm_list_return stm_list85 =null;


        PascalTree WHILE82_tree=null;
        PascalTree DO84_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:136:3: ( WHILE ^ expr DO ! stm_list )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:137:3: WHILE ^ expr DO ! stm_list
            {
            root_0 = (PascalTree)adaptor.nil();


            WHILE82=(Token)match(input,WHILE,FOLLOW_WHILE_in_while_stm912); 
            WHILE82_tree = 
            (PascalTree)adaptor.create(WHILE82)
            ;
            root_0 = (PascalTree)adaptor.becomeRoot(WHILE82_tree, root_0);


            pushFollow(FOLLOW_expr_in_while_stm915);
            expr83=expr();

            state._fsp--;

            adaptor.addChild(root_0, expr83.getTree());

            DO84=(Token)match(input,DO,FOLLOW_DO_in_while_stm917); 

            pushFollow(FOLLOW_stm_list_in_while_stm920);
            stm_list85=stm_list();

            state._fsp--;

            adaptor.addChild(root_0, stm_list85.getTree());

            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "while_stm"


    public static class explicit_param_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "explicit_param"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:140:1: explicit_param : expr ( COMMA ! expr )* ;
    public final PascalFunParser.explicit_param_return explicit_param() throws RecognitionException {
        PascalFunParser.explicit_param_return retval = new PascalFunParser.explicit_param_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token COMMA87=null;
        PascalFunParser.expr_return expr86 =null;

        PascalFunParser.expr_return expr88 =null;


        PascalTree COMMA87_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:141:3: ( expr ( COMMA ! expr )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:142:3: expr ( COMMA ! expr )*
            {
            root_0 = (PascalTree)adaptor.nil();


            pushFollow(FOLLOW_expr_in_explicit_param937);
            expr86=expr();

            state._fsp--;

            adaptor.addChild(root_0, expr86.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:142:8: ( COMMA ! expr )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==COMMA) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:142:9: COMMA ! expr
            	    {
            	    COMMA87=(Token)match(input,COMMA,FOLLOW_COMMA_in_explicit_param940); 

            	    pushFollow(FOLLOW_expr_in_explicit_param943);
            	    expr88=expr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expr88.getTree());

            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "explicit_param"


    public static class last_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "last"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:145:1: last : (a= IDENT ( ( LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS ) -> ^( CALL $a $b) | -> $a) | NUMBER | STRING | BOOLEAN | LEFT_PARENTESIS ! expr RIGHT_PARENTESIS !);
    public final PascalFunParser.last_return last() throws RecognitionException {
        PascalFunParser.last_return retval = new PascalFunParser.last_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token a=null;
        Token LEFT_PARENTESIS89=null;
        Token RIGHT_PARENTESIS90=null;
        Token NUMBER91=null;
        Token STRING92=null;
        Token BOOLEAN93=null;
        Token LEFT_PARENTESIS94=null;
        Token RIGHT_PARENTESIS96=null;
        PascalFunParser.functional_param_decl_return b =null;

        PascalFunParser.expr_return expr95 =null;


        PascalTree a_tree=null;
        PascalTree LEFT_PARENTESIS89_tree=null;
        PascalTree RIGHT_PARENTESIS90_tree=null;
        PascalTree NUMBER91_tree=null;
        PascalTree STRING92_tree=null;
        PascalTree BOOLEAN93_tree=null;
        PascalTree LEFT_PARENTESIS94_tree=null;
        PascalTree RIGHT_PARENTESIS96_tree=null;
        RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
        RewriteRuleTokenStream stream_LEFT_PARENTESIS=new RewriteRuleTokenStream(adaptor,"token LEFT_PARENTESIS");
        RewriteRuleTokenStream stream_RIGHT_PARENTESIS=new RewriteRuleTokenStream(adaptor,"token RIGHT_PARENTESIS");
        RewriteRuleSubtreeStream stream_functional_param_decl=new RewriteRuleSubtreeStream(adaptor,"rule functional_param_decl");
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:146:3: (a= IDENT ( ( LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS ) -> ^( CALL $a $b) | -> $a) | NUMBER | STRING | BOOLEAN | LEFT_PARENTESIS ! expr RIGHT_PARENTESIS !)
            int alt24=5;
            switch ( input.LA(1) ) {
            case IDENT:
                {
                alt24=1;
                }
                break;
            case NUMBER:
                {
                alt24=2;
                }
                break;
            case STRING:
                {
                alt24=3;
                }
                break;
            case BOOLEAN:
                {
                alt24=4;
                }
                break;
            case LEFT_PARENTESIS:
                {
                alt24=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;

            }

            switch (alt24) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:147:3: a= IDENT ( ( LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS ) -> ^( CALL $a $b) | -> $a)
                    {
                    a=(Token)match(input,IDENT,FOLLOW_IDENT_in_last964);  
                    stream_IDENT.add(a);


                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:147:11: ( ( LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS ) -> ^( CALL $a $b) | -> $a)
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==LEFT_PARENTESIS) ) {
                        alt23=1;
                    }
                    else if ( (LA23_0==EOF||LA23_0==ASSIGN||(LA23_0 >= COLON && LA23_0 <= DIFFERENT)||LA23_0==DO||LA23_0==EQUALS||(LA23_0 >= GET && LA23_0 <= GT)||LA23_0==LET||(LA23_0 >= LT && LA23_0 <= MINUS)||LA23_0==PLUS||(LA23_0 >= RIGHT_PARENTESIS && LA23_0 <= SLASH)||(LA23_0 >= THEN && LA23_0 <= TIMES)) ) {
                        alt23=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 0, input);

                        throw nvae;

                    }
                    switch (alt23) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:148:5: ( LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS )
                            {
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:148:5: ( LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS )
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:148:6: LEFT_PARENTESIS b= functional_param_decl RIGHT_PARENTESIS
                            {
                            LEFT_PARENTESIS89=(Token)match(input,LEFT_PARENTESIS,FOLLOW_LEFT_PARENTESIS_in_last974);  
                            stream_LEFT_PARENTESIS.add(LEFT_PARENTESIS89);


                            pushFollow(FOLLOW_functional_param_decl_in_last978);
                            b=functional_param_decl();

                            state._fsp--;

                            stream_functional_param_decl.add(b.getTree());

                            RIGHT_PARENTESIS90=(Token)match(input,RIGHT_PARENTESIS,FOLLOW_RIGHT_PARENTESIS_in_last980);  
                            stream_RIGHT_PARENTESIS.add(RIGHT_PARENTESIS90);


                            }


                            // AST REWRITE
                            // elements: b, a
                            // token labels: a
                            // rule labels: retval, b
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleTokenStream stream_a=new RewriteRuleTokenStream(adaptor,"token a",a);
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                            RewriteRuleSubtreeStream stream_b=new RewriteRuleSubtreeStream(adaptor,"rule b",b!=null?b.tree:null);

                            root_0 = (PascalTree)adaptor.nil();
                            // 148:64: -> ^( CALL $a $b)
                            {
                                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:148:67: ^( CALL $a $b)
                                {
                                PascalTree root_1 = (PascalTree)adaptor.nil();
                                root_1 = (PascalTree)adaptor.becomeRoot(
                                (PascalTree)adaptor.create(CALL, "CALL")
                                , root_1);

                                adaptor.addChild(root_1, stream_a.nextNode());

                                adaptor.addChild(root_1, stream_b.nextTree());

                                adaptor.addChild(root_0, root_1);
                                }

                            }


                            retval.tree = root_0;

                            }
                            break;
                        case 2 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:149:7: 
                            {
                            // AST REWRITE
                            // elements: a
                            // token labels: a
                            // rule labels: retval
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleTokenStream stream_a=new RewriteRuleTokenStream(adaptor,"token a",a);
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                            root_0 = (PascalTree)adaptor.nil();
                            // 149:7: -> $a
                            {
                                adaptor.addChild(root_0, stream_a.nextNode());

                            }


                            retval.tree = root_0;

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:151:5: NUMBER
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    NUMBER91=(Token)match(input,NUMBER,FOLLOW_NUMBER_in_last1016); 
                    NUMBER91_tree = 
                    (PascalTree)adaptor.create(NUMBER91)
                    ;
                    adaptor.addChild(root_0, NUMBER91_tree);


                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:152:5: STRING
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    STRING92=(Token)match(input,STRING,FOLLOW_STRING_in_last1022); 
                    STRING92_tree = 
                    (PascalTree)adaptor.create(STRING92)
                    ;
                    adaptor.addChild(root_0, STRING92_tree);


                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:153:5: BOOLEAN
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    BOOLEAN93=(Token)match(input,BOOLEAN,FOLLOW_BOOLEAN_in_last1028); 
                    BOOLEAN93_tree = 
                    (PascalTree)adaptor.create(BOOLEAN93)
                    ;
                    adaptor.addChild(root_0, BOOLEAN93_tree);


                    }
                    break;
                case 5 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:154:5: LEFT_PARENTESIS ! expr RIGHT_PARENTESIS !
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    LEFT_PARENTESIS94=(Token)match(input,LEFT_PARENTESIS,FOLLOW_LEFT_PARENTESIS_in_last1034); 

                    pushFollow(FOLLOW_expr_in_last1037);
                    expr95=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr95.getTree());

                    RIGHT_PARENTESIS96=(Token)match(input,RIGHT_PARENTESIS,FOLLOW_RIGHT_PARENTESIS_in_last1039); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "last"


    public static class unary_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "unary"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:157:1: unary : ( NOT ^ last | MINUS ^ last | last );
    public final PascalFunParser.unary_return unary() throws RecognitionException {
        PascalFunParser.unary_return retval = new PascalFunParser.unary_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token NOT97=null;
        Token MINUS99=null;
        PascalFunParser.last_return last98 =null;

        PascalFunParser.last_return last100 =null;

        PascalFunParser.last_return last101 =null;


        PascalTree NOT97_tree=null;
        PascalTree MINUS99_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:158:3: ( NOT ^ last | MINUS ^ last | last )
            int alt25=3;
            switch ( input.LA(1) ) {
            case NOT:
                {
                alt25=1;
                }
                break;
            case MINUS:
                {
                alt25=2;
                }
                break;
            case BOOLEAN:
            case IDENT:
            case LEFT_PARENTESIS:
            case NUMBER:
            case STRING:
                {
                alt25=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;

            }

            switch (alt25) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:159:3: NOT ^ last
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    NOT97=(Token)match(input,NOT,FOLLOW_NOT_in_unary1057); 
                    NOT97_tree = 
                    (PascalTree)adaptor.create(NOT97)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(NOT97_tree, root_0);


                    pushFollow(FOLLOW_last_in_unary1060);
                    last98=last();

                    state._fsp--;

                    adaptor.addChild(root_0, last98.getTree());

                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:160:5: MINUS ^ last
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    MINUS99=(Token)match(input,MINUS,FOLLOW_MINUS_in_unary1066); 
                    MINUS99_tree = 
                    (PascalTree)adaptor.create(MINUS99)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(MINUS99_tree, root_0);


                    pushFollow(FOLLOW_last_in_unary1069);
                    last100=last();

                    state._fsp--;

                    adaptor.addChild(root_0, last100.getTree());

                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:161:5: last
                    {
                    root_0 = (PascalTree)adaptor.nil();


                    pushFollow(FOLLOW_last_in_unary1075);
                    last101=last();

                    state._fsp--;

                    adaptor.addChild(root_0, last101.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "unary"


    public static class add_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "add"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:164:1: add : unary ( ( PLUS | MINUS ) ^ unary )* ;
    public final PascalFunParser.add_return add() throws RecognitionException {
        PascalFunParser.add_return retval = new PascalFunParser.add_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token set103=null;
        PascalFunParser.unary_return unary102 =null;

        PascalFunParser.unary_return unary104 =null;


        PascalTree set103_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:165:3: ( unary ( ( PLUS | MINUS ) ^ unary )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:166:3: unary ( ( PLUS | MINUS ) ^ unary )*
            {
            root_0 = (PascalTree)adaptor.nil();


            pushFollow(FOLLOW_unary_in_add1092);
            unary102=unary();

            state._fsp--;

            adaptor.addChild(root_0, unary102.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:166:9: ( ( PLUS | MINUS ) ^ unary )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==MINUS||LA26_0==PLUS) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:166:10: ( PLUS | MINUS ) ^ unary
            	    {
            	    set103=(Token)input.LT(1);

            	    set103=(Token)input.LT(1);

            	    if ( input.LA(1)==MINUS||input.LA(1)==PLUS ) {
            	        input.consume();
            	        root_0 = (PascalTree)adaptor.becomeRoot(
            	        (PascalTree)adaptor.create(set103)
            	        , root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    pushFollow(FOLLOW_unary_in_add1104);
            	    unary104=unary();

            	    state._fsp--;

            	    adaptor.addChild(root_0, unary104.getTree());

            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "add"


    public static class mult_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "mult"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:169:1: mult : add ( ( TIMES | SLASH ) ^ add )* ;
    public final PascalFunParser.mult_return mult() throws RecognitionException {
        PascalFunParser.mult_return retval = new PascalFunParser.mult_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token set106=null;
        PascalFunParser.add_return add105 =null;

        PascalFunParser.add_return add107 =null;


        PascalTree set106_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:170:3: ( add ( ( TIMES | SLASH ) ^ add )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:171:3: add ( ( TIMES | SLASH ) ^ add )*
            {
            root_0 = (PascalTree)adaptor.nil();


            pushFollow(FOLLOW_add_in_mult1123);
            add105=add();

            state._fsp--;

            adaptor.addChild(root_0, add105.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:171:7: ( ( TIMES | SLASH ) ^ add )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==SLASH||LA27_0==TIMES) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:171:8: ( TIMES | SLASH ) ^ add
            	    {
            	    set106=(Token)input.LT(1);

            	    set106=(Token)input.LT(1);

            	    if ( input.LA(1)==SLASH||input.LA(1)==TIMES ) {
            	        input.consume();
            	        root_0 = (PascalTree)adaptor.becomeRoot(
            	        (PascalTree)adaptor.create(set106)
            	        , root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    pushFollow(FOLLOW_add_in_mult1135);
            	    add107=add();

            	    state._fsp--;

            	    adaptor.addChild(root_0, add107.getTree());

            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "mult"


    public static class logical_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "logical"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:174:1: logical : mult ( ( LT | EQUALS | GT | DIFFERENT | LET | GET ) ^ mult )* ;
    public final PascalFunParser.logical_return logical() throws RecognitionException {
        PascalFunParser.logical_return retval = new PascalFunParser.logical_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token set109=null;
        PascalFunParser.mult_return mult108 =null;

        PascalFunParser.mult_return mult110 =null;


        PascalTree set109_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:175:3: ( mult ( ( LT | EQUALS | GT | DIFFERENT | LET | GET ) ^ mult )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:176:3: mult ( ( LT | EQUALS | GT | DIFFERENT | LET | GET ) ^ mult )*
            {
            root_0 = (PascalTree)adaptor.nil();


            pushFollow(FOLLOW_mult_in_logical1154);
            mult108=mult();

            state._fsp--;

            adaptor.addChild(root_0, mult108.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:176:8: ( ( LT | EQUALS | GT | DIFFERENT | LET | GET ) ^ mult )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==DIFFERENT||LA28_0==EQUALS||(LA28_0 >= GET && LA28_0 <= GT)||LA28_0==LET||LA28_0==LT) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:176:9: ( LT | EQUALS | GT | DIFFERENT | LET | GET ) ^ mult
            	    {
            	    set109=(Token)input.LT(1);

            	    set109=(Token)input.LT(1);

            	    if ( input.LA(1)==DIFFERENT||input.LA(1)==EQUALS||(input.LA(1) >= GET && input.LA(1) <= GT)||input.LA(1)==LET||input.LA(1)==LT ) {
            	        input.consume();
            	        root_0 = (PascalTree)adaptor.becomeRoot(
            	        (PascalTree)adaptor.create(set109)
            	        , root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }


            	    pushFollow(FOLLOW_mult_in_logical1182);
            	    mult110=mult();

            	    state._fsp--;

            	    adaptor.addChild(root_0, mult110.getTree());

            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "logical"


    public static class expr_return extends ParserRuleReturnScope {
        PascalTree tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "expr"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:179:1: expr : logical ( ASSIGN ^ logical )? ;
    public final PascalFunParser.expr_return expr() throws RecognitionException {
        PascalFunParser.expr_return retval = new PascalFunParser.expr_return();
        retval.start = input.LT(1);


        PascalTree root_0 = null;

        Token ASSIGN112=null;
        PascalFunParser.logical_return logical111 =null;

        PascalFunParser.logical_return logical113 =null;


        PascalTree ASSIGN112_tree=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:180:3: ( logical ( ASSIGN ^ logical )? )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:181:3: logical ( ASSIGN ^ logical )?
            {
            root_0 = (PascalTree)adaptor.nil();


            pushFollow(FOLLOW_logical_in_expr1201);
            logical111=logical();

            state._fsp--;

            adaptor.addChild(root_0, logical111.getTree());

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:181:11: ( ASSIGN ^ logical )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==ASSIGN) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:181:12: ASSIGN ^ logical
                    {
                    ASSIGN112=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_expr1204); 
                    ASSIGN112_tree = 
                    (PascalTree)adaptor.create(ASSIGN112)
                    ;
                    root_0 = (PascalTree)adaptor.becomeRoot(ASSIGN112_tree, root_0);


                    pushFollow(FOLLOW_logical_in_expr1207);
                    logical113=logical();

                    state._fsp--;

                    adaptor.addChild(root_0, logical113.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);


            retval.tree = (PascalTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "expr"

    // Delegated rules


 

    public static final BitSet FOLLOW_PROGRAM_in_program363 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_program366 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_program368 = new BitSet(new long[]{0x0001000002010000L});
    public static final BitSet FOLLOW_uses_decl_in_program371 = new BitSet(new long[]{0x0000000002010000L});
    public static final BitSet FOLLOW_implementation_block_in_program374 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_END_in_program377 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_DOT_in_program380 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_program383 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_USES_in_uses_decl398 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_uses_decl401 = new BitSet(new long[]{0x0000020000000400L});
    public static final BitSet FOLLOW_COMMA_in_uses_decl404 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_uses_decl407 = new BitSet(new long[]{0x0000020000000400L});
    public static final BitSet FOLLOW_SEMICOLON_in_uses_decl411 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VAR_in_var_decl427 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_var_decl431 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_COLON_in_var_decl433 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_decl_in_var_decl436 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_var_decl438 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_IDENT_in_param_decl458 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_COLON_in_param_decl460 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_decl_in_param_decl464 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_COMMA_in_param_decl467 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_param_decl471 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_COLON_in_param_decl473 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_decl_in_param_decl477 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_IDENT_in_type_decl515 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_in_type_decl521 = new BitSet(new long[]{0x0000000404000000L});
    public static final BitSet FOLLOW_LEFT_BRACKET_in_type_decl525 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_NUMBER_in_type_decl528 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_TWO_DOTS_in_type_decl530 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_NUMBER_in_type_decl533 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_RIGHT_BRACKET_in_type_decl535 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_OF_in_type_decl540 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_decl_in_type_decl543 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IMPLEMENTATION_in_implementation_block558 = new BitSet(new long[]{0x00020020000C0002L});
    public static final BitSet FOLLOW_impl_member_decl_in_implementation_block563 = new BitSet(new long[]{0x00020020000C0002L});
    public static final BitSet FOLLOW_var_decl_in_impl_member_decl581 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_impl_member_decl587 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_impl_member_decl590 = new BitSet(new long[]{0x0000000008000200L});
    public static final BitSet FOLLOW_LEFT_PARENTESIS_in_impl_member_decl593 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_param_decl_in_impl_member_decl596 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_RIGHT_PARENTESIS_in_impl_member_decl598 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_COLON_in_impl_member_decl603 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_impl_member_decl606 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_impl_member_decl608 = new BitSet(new long[]{0x0002000000000040L});
    public static final BitSet FOLLOW_var_decl_in_impl_member_decl611 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_method_stm_list_in_impl_member_decl614 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROCEDURE_in_impl_member_decl621 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_impl_member_decl624 = new BitSet(new long[]{0x0000020008000000L});
    public static final BitSet FOLLOW_LEFT_PARENTESIS_in_impl_member_decl627 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_param_decl_in_impl_member_decl630 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_RIGHT_PARENTESIS_in_impl_member_decl632 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_impl_member_decl637 = new BitSet(new long[]{0x0002000000000040L});
    public static final BitSet FOLLOW_var_decl_in_impl_member_decl640 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_method_stm_list_in_impl_member_decl643 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTIONAL_in_impl_member_decl649 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_impl_member_decl652 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_LEFT_PARENTESIS_in_impl_member_decl654 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_functional_param_decl_in_impl_member_decl657 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_RIGHT_PARENTESIS_in_impl_member_decl659 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_COLON_in_impl_member_decl662 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_IDENT_in_impl_member_decl665 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_EQUALS_in_impl_member_decl667 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_expr_in_impl_member_decl670 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_impl_member_decl672 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expr_in_functional_param_decl693 = new BitSet(new long[]{0x0000000000000602L});
    public static final BitSet FOLLOW_COLON_in_functional_param_decl696 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_decl_in_functional_param_decl700 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_COMMA_in_functional_param_decl707 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_expr_in_functional_param_decl711 = new BitSet(new long[]{0x0000000000000602L});
    public static final BitSet FOLLOW_COLON_in_functional_param_decl714 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_decl_in_functional_param_decl718 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_BEGIN_in_stm_list762 = new BitSet(new long[]{0x0004100389810080L});
    public static final BitSet FOLLOW_stm_in_stm_list767 = new BitSet(new long[]{0x0004100389810080L});
    public static final BitSet FOLLOW_END_in_stm_list771 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_stm_list773 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_stm_in_stm_list789 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BEGIN_in_method_stm_list806 = new BitSet(new long[]{0x0004100389810080L});
    public static final BitSet FOLLOW_stm_in_method_stm_list811 = new BitSet(new long[]{0x0004100389810080L});
    public static final BitSet FOLLOW_END_in_method_stm_list815 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_method_stm_list817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_if_stm_in_stm846 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_while_stm_in_stm852 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expr_in_stm858 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_SEMICOLON_in_stm860 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_in_if_stm878 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_expr_in_if_stm881 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_THEN_in_if_stm883 = new BitSet(new long[]{0x00041003898000C0L});
    public static final BitSet FOLLOW_stm_list_in_if_stm886 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_ELSE_in_if_stm889 = new BitSet(new long[]{0x00041003898000C0L});
    public static final BitSet FOLLOW_stm_list_in_if_stm891 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_in_while_stm912 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_expr_in_while_stm915 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_DO_in_while_stm917 = new BitSet(new long[]{0x00041003898000C0L});
    public static final BitSet FOLLOW_stm_list_in_while_stm920 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expr_in_explicit_param937 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_COMMA_in_explicit_param940 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_expr_in_explicit_param943 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_IDENT_in_last964 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_LEFT_PARENTESIS_in_last974 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_functional_param_decl_in_last978 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_RIGHT_PARENTESIS_in_last980 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_last1016 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_last1022 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BOOLEAN_in_last1028 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LEFT_PARENTESIS_in_last1034 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_expr_in_last1037 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_RIGHT_PARENTESIS_in_last1039 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_unary1057 = new BitSet(new long[]{0x0000100208800080L});
    public static final BitSet FOLLOW_last_in_unary1060 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MINUS_in_unary1066 = new BitSet(new long[]{0x0000100208800080L});
    public static final BitSet FOLLOW_last_in_unary1069 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_last_in_unary1075 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unary_in_add1092 = new BitSet(new long[]{0x0000001080000002L});
    public static final BitSet FOLLOW_set_in_add1095 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_unary_in_add1104 = new BitSet(new long[]{0x0000001080000002L});
    public static final BitSet FOLLOW_add_in_mult1123 = new BitSet(new long[]{0x0000440000000002L});
    public static final BitSet FOLLOW_set_in_mult1126 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_add_in_mult1135 = new BitSet(new long[]{0x0000440000000002L});
    public static final BitSet FOLLOW_mult_in_logical1154 = new BitSet(new long[]{0x0000000050620802L});
    public static final BitSet FOLLOW_set_in_logical1157 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_mult_in_logical1182 = new BitSet(new long[]{0x0000000050620802L});
    public static final BitSet FOLLOW_logical_in_expr1201 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_ASSIGN_in_expr1204 = new BitSet(new long[]{0x0000100388800080L});
    public static final BitSet FOLLOW_logical_in_expr1207 = new BitSet(new long[]{0x0000000000000002L});

}