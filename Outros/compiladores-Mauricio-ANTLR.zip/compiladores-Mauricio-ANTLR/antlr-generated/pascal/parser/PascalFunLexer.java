// $ANTLR 3.4 /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g 2012-12-05 09:43:52

package pascal.parser;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked"})
public class PascalFunLexer extends Lexer {
    public static final int EOF=-1;
    public static final int ARRAY=4;
    public static final int ASSIGN=5;
    public static final int BEGIN=6;
    public static final int BOOLEAN=7;
    public static final int CALL=8;
    public static final int COLON=9;
    public static final int COMMA=10;
    public static final int DIFFERENT=11;
    public static final int DIGIT=12;
    public static final int DO=13;
    public static final int DOT=14;
    public static final int ELSE=15;
    public static final int END=16;
    public static final int EQUALS=17;
    public static final int FUNCTION=18;
    public static final int FUNCTIONAL=19;
    public static final int FUNCTIONAL_PARAM=20;
    public static final int GET=21;
    public static final int GT=22;
    public static final int IDENT=23;
    public static final int IF=24;
    public static final int IMPLEMENTATION=25;
    public static final int LEFT_BRACKET=26;
    public static final int LEFT_PARENTESIS=27;
    public static final int LET=28;
    public static final int LETTER=29;
    public static final int LT=30;
    public static final int MINUS=31;
    public static final int NOT=32;
    public static final int NUMBER=33;
    public static final int OF=34;
    public static final int PARAM=35;
    public static final int PLUS=36;
    public static final int PROCEDURE=37;
    public static final int PROGRAM=38;
    public static final int RIGHT_BRACKET=39;
    public static final int RIGHT_PARENTESIS=40;
    public static final int SEMICOLON=41;
    public static final int SLASH=42;
    public static final int STM_LIST=43;
    public static final int STRING=44;
    public static final int THEN=45;
    public static final int TIMES=46;
    public static final int TWO_DOTS=47;
    public static final int USES=48;
    public static final int VAR=49;
    public static final int WHILE=50;
    public static final int WHITESPACE=51;

    // delegates
    // delegators
    public Lexer[] getDelegates() {
        return new Lexer[] {};
    }

    public PascalFunLexer() {} 
    public PascalFunLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public PascalFunLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);
    }
    public String getGrammarFileName() { return "/home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g"; }

    // $ANTLR start "ARRAY"
    public final void mARRAY() throws RecognitionException {
        try {
            int _type = ARRAY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:11:7: ( 'array' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:11:9: 'array'
            {
            match("array"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "ARRAY"

    // $ANTLR start "ASSIGN"
    public final void mASSIGN() throws RecognitionException {
        try {
            int _type = ASSIGN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:12:8: ( ':=' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:12:10: ':='
            {
            match(":="); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "ASSIGN"

    // $ANTLR start "BEGIN"
    public final void mBEGIN() throws RecognitionException {
        try {
            int _type = BEGIN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:13:7: ( 'begin' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:13:9: 'begin'
            {
            match("begin"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "BEGIN"

    // $ANTLR start "COLON"
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:14:7: ( ':' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:14:9: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "COLON"

    // $ANTLR start "COMMA"
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:15:7: ( ',' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:15:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "COMMA"

    // $ANTLR start "DIFFERENT"
    public final void mDIFFERENT() throws RecognitionException {
        try {
            int _type = DIFFERENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:16:11: ( '<>' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:16:13: '<>'
            {
            match("<>"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "DIFFERENT"

    // $ANTLR start "DO"
    public final void mDO() throws RecognitionException {
        try {
            int _type = DO;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:17:4: ( 'do' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:17:6: 'do'
            {
            match("do"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "DO"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:18:5: ( '.' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:18:7: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "ELSE"
    public final void mELSE() throws RecognitionException {
        try {
            int _type = ELSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:19:6: ( 'else' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:19:8: 'else'
            {
            match("else"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "ELSE"

    // $ANTLR start "END"
    public final void mEND() throws RecognitionException {
        try {
            int _type = END;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:20:5: ( 'end' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:20:7: 'end'
            {
            match("end"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "END"

    // $ANTLR start "EQUALS"
    public final void mEQUALS() throws RecognitionException {
        try {
            int _type = EQUALS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:21:8: ( '=' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:21:10: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "EQUALS"

    // $ANTLR start "FUNCTION"
    public final void mFUNCTION() throws RecognitionException {
        try {
            int _type = FUNCTION;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:22:10: ( 'function' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:22:12: 'function'
            {
            match("function"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "FUNCTION"

    // $ANTLR start "FUNCTIONAL"
    public final void mFUNCTIONAL() throws RecognitionException {
        try {
            int _type = FUNCTIONAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:23:12: ( 'functional' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:23:14: 'functional'
            {
            match("functional"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "FUNCTIONAL"

    // $ANTLR start "GET"
    public final void mGET() throws RecognitionException {
        try {
            int _type = GET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:24:5: ( '>=' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:24:7: '>='
            {
            match(">="); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "GET"

    // $ANTLR start "GT"
    public final void mGT() throws RecognitionException {
        try {
            int _type = GT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:25:4: ( '>' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:25:6: '>'
            {
            match('>'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "GT"

    // $ANTLR start "IF"
    public final void mIF() throws RecognitionException {
        try {
            int _type = IF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:26:4: ( 'if' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:26:6: 'if'
            {
            match("if"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "IF"

    // $ANTLR start "IMPLEMENTATION"
    public final void mIMPLEMENTATION() throws RecognitionException {
        try {
            int _type = IMPLEMENTATION;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:27:16: ( 'implementation' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:27:18: 'implementation'
            {
            match("implementation"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "IMPLEMENTATION"

    // $ANTLR start "LEFT_BRACKET"
    public final void mLEFT_BRACKET() throws RecognitionException {
        try {
            int _type = LEFT_BRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:28:14: ( '[' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:28:16: '['
            {
            match('['); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "LEFT_BRACKET"

    // $ANTLR start "LEFT_PARENTESIS"
    public final void mLEFT_PARENTESIS() throws RecognitionException {
        try {
            int _type = LEFT_PARENTESIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:29:17: ( '(' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:29:19: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "LEFT_PARENTESIS"

    // $ANTLR start "LET"
    public final void mLET() throws RecognitionException {
        try {
            int _type = LET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:30:5: ( '<=' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:30:7: '<='
            {
            match("<="); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "LET"

    // $ANTLR start "LT"
    public final void mLT() throws RecognitionException {
        try {
            int _type = LT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:31:4: ( '<' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:31:6: '<'
            {
            match('<'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "LT"

    // $ANTLR start "MINUS"
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:32:7: ( '-' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:32:9: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "MINUS"

    // $ANTLR start "NOT"
    public final void mNOT() throws RecognitionException {
        try {
            int _type = NOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:33:5: ( 'not' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:33:7: 'not'
            {
            match("not"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "NOT"

    // $ANTLR start "OF"
    public final void mOF() throws RecognitionException {
        try {
            int _type = OF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:34:4: ( 'of' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:34:6: 'of'
            {
            match("of"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "OF"

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:35:6: ( '+' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:35:8: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "PROCEDURE"
    public final void mPROCEDURE() throws RecognitionException {
        try {
            int _type = PROCEDURE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:36:11: ( 'procedure' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:36:13: 'procedure'
            {
            match("procedure"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "PROCEDURE"

    // $ANTLR start "PROGRAM"
    public final void mPROGRAM() throws RecognitionException {
        try {
            int _type = PROGRAM;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:37:9: ( 'program' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:37:11: 'program'
            {
            match("program"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "PROGRAM"

    // $ANTLR start "RIGHT_BRACKET"
    public final void mRIGHT_BRACKET() throws RecognitionException {
        try {
            int _type = RIGHT_BRACKET;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:38:15: ( ']' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:38:17: ']'
            {
            match(']'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "RIGHT_BRACKET"

    // $ANTLR start "RIGHT_PARENTESIS"
    public final void mRIGHT_PARENTESIS() throws RecognitionException {
        try {
            int _type = RIGHT_PARENTESIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:39:18: ( ')' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:39:20: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "RIGHT_PARENTESIS"

    // $ANTLR start "SEMICOLON"
    public final void mSEMICOLON() throws RecognitionException {
        try {
            int _type = SEMICOLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:40:11: ( ';' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:40:13: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "SEMICOLON"

    // $ANTLR start "SLASH"
    public final void mSLASH() throws RecognitionException {
        try {
            int _type = SLASH;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:41:7: ( '/' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:41:9: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "SLASH"

    // $ANTLR start "THEN"
    public final void mTHEN() throws RecognitionException {
        try {
            int _type = THEN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:42:6: ( 'then' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:42:8: 'then'
            {
            match("then"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "THEN"

    // $ANTLR start "TIMES"
    public final void mTIMES() throws RecognitionException {
        try {
            int _type = TIMES;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:43:7: ( '*' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:43:9: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "TIMES"

    // $ANTLR start "TWO_DOTS"
    public final void mTWO_DOTS() throws RecognitionException {
        try {
            int _type = TWO_DOTS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:44:10: ( '..' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:44:12: '..'
            {
            match(".."); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "TWO_DOTS"

    // $ANTLR start "USES"
    public final void mUSES() throws RecognitionException {
        try {
            int _type = USES;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:45:6: ( 'uses' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:45:8: 'uses'
            {
            match("uses"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "USES"

    // $ANTLR start "VAR"
    public final void mVAR() throws RecognitionException {
        try {
            int _type = VAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:46:5: ( 'var' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:46:7: 'var'
            {
            match("var"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "VAR"

    // $ANTLR start "WHILE"
    public final void mWHILE() throws RecognitionException {
        try {
            int _type = WHILE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:47:7: ( 'while' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:47:9: 'while'
            {
            match("while"); 



            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "WHILE"

    // $ANTLR start "WHITESPACE"
    public final void mWHITESPACE() throws RecognitionException {
        try {
            int _type = WHITESPACE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:185:3: ( ( '\\t' | ' ' | '\\r' | '\\n' | '\\f' )+ )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:186:3: ( '\\t' | ' ' | '\\r' | '\\n' | '\\f' )+
            {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:186:3: ( '\\t' | ' ' | '\\r' | '\\n' | '\\f' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0 >= '\t' && LA1_0 <= '\n')||(LA1_0 >= '\f' && LA1_0 <= '\r')||LA1_0==' ') ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:
            	    {
            	    if ( (input.LA(1) >= '\t' && input.LA(1) <= '\n')||(input.LA(1) >= '\f' && input.LA(1) <= '\r')||input.LA(1)==' ' ) {
            	        input.consume();
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);



               _channel = HIDDEN;
              

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "WHITESPACE"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:204:3: ( 'a' .. 'z' | 'A' .. 'Z' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:
            {
            if ( (input.LA(1) >= 'A' && input.LA(1) <= 'Z')||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
                input.consume();
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;
            }


            }


        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "DIGIT"
    public final void mDIGIT() throws RecognitionException {
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:211:3: ( '0' .. '9' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:
            {
            if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
                input.consume();
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;
            }


            }


        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "DIGIT"

    // $ANTLR start "BOOLEAN"
    public final void mBOOLEAN() throws RecognitionException {
        try {
            int _type = BOOLEAN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:214:3: ( 'true' | 'false' )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='t') ) {
                alt2=1;
            }
            else if ( (LA2_0=='f') ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;

            }
            switch (alt2) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:215:3: 'true'
                    {
                    match("true"); 



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:216:5: 'false'
                    {
                    match("false"); 



                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "BOOLEAN"

    // $ANTLR start "IDENT"
    public final void mIDENT() throws RecognitionException {
        try {
            int _type = IDENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:220:3: ( LETTER ( LETTER | DIGIT )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:221:3: LETTER ( LETTER | DIGIT )*
            {
            mLETTER(); 


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:222:3: ( LETTER | DIGIT )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0 >= '0' && LA3_0 <= '9')||(LA3_0 >= 'A' && LA3_0 <= 'Z')||(LA3_0 >= 'a' && LA3_0 <= 'z')) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:
            	    {
            	    if ( (input.LA(1) >= '0' && input.LA(1) <= '9')||(input.LA(1) >= 'A' && input.LA(1) <= 'Z')||(input.LA(1) >= 'a' && input.LA(1) <= 'z') ) {
            	        input.consume();
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "IDENT"

    // $ANTLR start "NUMBER"
    public final void mNUMBER() throws RecognitionException {
        try {
            int _type = NUMBER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:229:3: ( DIGIT ( DIGIT )* )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:230:3: DIGIT ( DIGIT )*
            {
            mDIGIT(); 


            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:230:9: ( DIGIT )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0 >= '0' && LA4_0 <= '9')) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:
            	    {
            	    if ( (input.LA(1) >= '0' && input.LA(1) <= '9') ) {
            	        input.consume();
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "NUMBER"

    // $ANTLR start "STRING"
    public final void mSTRING() throws RecognitionException {
        try {
            int _type = STRING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:234:3: ( '\"' (~ ( '\"' | '\\\\' ) )* '\"' )
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:235:3: '\"' (~ ( '\"' | '\\\\' ) )* '\"'
            {
            match('\"'); 

            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:235:7: (~ ( '\"' | '\\\\' ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0 >= '\u0000' && LA5_0 <= '!')||(LA5_0 >= '#' && LA5_0 <= '[')||(LA5_0 >= ']' && LA5_0 <= '\uFFFF')) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:
            	    {
            	    if ( (input.LA(1) >= '\u0000' && input.LA(1) <= '!')||(input.LA(1) >= '#' && input.LA(1) <= '[')||(input.LA(1) >= ']' && input.LA(1) <= '\uFFFF') ) {
            	        input.consume();
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            match('\"'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        	// do for sure before leaving
        }
    }
    // $ANTLR end "STRING"

    public void mTokens() throws RecognitionException {
        // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:8: ( ARRAY | ASSIGN | BEGIN | COLON | COMMA | DIFFERENT | DO | DOT | ELSE | END | EQUALS | FUNCTION | FUNCTIONAL | GET | GT | IF | IMPLEMENTATION | LEFT_BRACKET | LEFT_PARENTESIS | LET | LT | MINUS | NOT | OF | PLUS | PROCEDURE | PROGRAM | RIGHT_BRACKET | RIGHT_PARENTESIS | SEMICOLON | SLASH | THEN | TIMES | TWO_DOTS | USES | VAR | WHILE | WHITESPACE | BOOLEAN | IDENT | NUMBER | STRING )
        int alt6=42;
        alt6 = dfa6.predict(input);
        switch (alt6) {
            case 1 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:10: ARRAY
                {
                mARRAY(); 


                }
                break;
            case 2 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:16: ASSIGN
                {
                mASSIGN(); 


                }
                break;
            case 3 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:23: BEGIN
                {
                mBEGIN(); 


                }
                break;
            case 4 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:29: COLON
                {
                mCOLON(); 


                }
                break;
            case 5 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:35: COMMA
                {
                mCOMMA(); 


                }
                break;
            case 6 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:41: DIFFERENT
                {
                mDIFFERENT(); 


                }
                break;
            case 7 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:51: DO
                {
                mDO(); 


                }
                break;
            case 8 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:54: DOT
                {
                mDOT(); 


                }
                break;
            case 9 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:58: ELSE
                {
                mELSE(); 


                }
                break;
            case 10 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:63: END
                {
                mEND(); 


                }
                break;
            case 11 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:67: EQUALS
                {
                mEQUALS(); 


                }
                break;
            case 12 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:74: FUNCTION
                {
                mFUNCTION(); 


                }
                break;
            case 13 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:83: FUNCTIONAL
                {
                mFUNCTIONAL(); 


                }
                break;
            case 14 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:94: GET
                {
                mGET(); 


                }
                break;
            case 15 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:98: GT
                {
                mGT(); 


                }
                break;
            case 16 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:101: IF
                {
                mIF(); 


                }
                break;
            case 17 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:104: IMPLEMENTATION
                {
                mIMPLEMENTATION(); 


                }
                break;
            case 18 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:119: LEFT_BRACKET
                {
                mLEFT_BRACKET(); 


                }
                break;
            case 19 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:132: LEFT_PARENTESIS
                {
                mLEFT_PARENTESIS(); 


                }
                break;
            case 20 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:148: LET
                {
                mLET(); 


                }
                break;
            case 21 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:152: LT
                {
                mLT(); 


                }
                break;
            case 22 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:155: MINUS
                {
                mMINUS(); 


                }
                break;
            case 23 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:161: NOT
                {
                mNOT(); 


                }
                break;
            case 24 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:165: OF
                {
                mOF(); 


                }
                break;
            case 25 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:168: PLUS
                {
                mPLUS(); 


                }
                break;
            case 26 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:173: PROCEDURE
                {
                mPROCEDURE(); 


                }
                break;
            case 27 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:183: PROGRAM
                {
                mPROGRAM(); 


                }
                break;
            case 28 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:191: RIGHT_BRACKET
                {
                mRIGHT_BRACKET(); 


                }
                break;
            case 29 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:205: RIGHT_PARENTESIS
                {
                mRIGHT_PARENTESIS(); 


                }
                break;
            case 30 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:222: SEMICOLON
                {
                mSEMICOLON(); 


                }
                break;
            case 31 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:232: SLASH
                {
                mSLASH(); 


                }
                break;
            case 32 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:238: THEN
                {
                mTHEN(); 


                }
                break;
            case 33 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:243: TIMES
                {
                mTIMES(); 


                }
                break;
            case 34 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:249: TWO_DOTS
                {
                mTWO_DOTS(); 


                }
                break;
            case 35 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:258: USES
                {
                mUSES(); 


                }
                break;
            case 36 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:263: VAR
                {
                mVAR(); 


                }
                break;
            case 37 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:267: WHILE
                {
                mWHILE(); 


                }
                break;
            case 38 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:273: WHITESPACE
                {
                mWHITESPACE(); 


                }
                break;
            case 39 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:284: BOOLEAN
                {
                mBOOLEAN(); 


                }
                break;
            case 40 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:292: IDENT
                {
                mIDENT(); 


                }
                break;
            case 41 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:298: NUMBER
                {
                mNUMBER(); 


                }
                break;
            case 42 :
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFun.g:1:305: STRING
                {
                mSTRING(); 


                }
                break;

        }

    }


    protected DFA6 dfa6 = new DFA6(this);
    static final String DFA6_eotS =
        "\1\uffff\1\36\1\43\1\36\1\uffff\1\47\1\36\1\52\1\36\1\uffff\1\36"+
        "\1\60\1\36\3\uffff\2\36\1\uffff\1\36\4\uffff\1\36\1\uffff\3\36\4"+
        "\uffff\1\36\2\uffff\1\36\3\uffff\1\75\2\uffff\4\36\2\uffff\1\102"+
        "\2\36\1\105\10\36\1\uffff\1\36\1\117\2\36\1\uffff\1\36\1\123\1\uffff"+
        "\4\36\1\131\3\36\1\135\1\uffff\3\36\1\uffff\2\36\1\143\1\144\1\145"+
        "\1\uffff\1\36\1\147\1\150\1\uffff\1\36\1\144\3\36\3\uffff\1\155"+
        "\2\uffff\4\36\1\uffff\3\36\1\165\1\167\2\36\1\uffff\1\36\1\uffff"+
        "\1\36\1\174\1\175\1\36\2\uffff\3\36\1\u0082\1\uffff";
    static final String DFA6_eofS =
        "\u0083\uffff";
    static final String DFA6_minS =
        "\1\11\1\162\1\75\1\145\1\uffff\1\75\1\157\1\56\1\154\1\uffff\1\141"+
        "\1\75\1\146\3\uffff\1\157\1\146\1\uffff\1\162\4\uffff\1\150\1\uffff"+
        "\1\163\1\141\1\150\4\uffff\1\162\2\uffff\1\147\3\uffff\1\60\2\uffff"+
        "\1\163\1\144\1\156\1\154\2\uffff\1\60\1\160\1\164\1\60\1\157\1\145"+
        "\1\165\1\145\1\162\1\151\1\141\1\151\1\uffff\1\145\1\60\1\143\1"+
        "\163\1\uffff\1\154\1\60\1\uffff\1\143\1\156\1\145\1\163\1\60\1\154"+
        "\1\171\1\156\1\60\1\uffff\1\164\2\145\1\uffff\1\145\1\162\3\60\1"+
        "\uffff\1\145\2\60\1\uffff\1\151\1\60\1\155\1\144\1\141\3\uffff\1"+
        "\60\2\uffff\1\157\1\145\1\165\1\155\1\uffff\2\156\1\162\2\60\1\164"+
        "\1\145\1\uffff\1\154\1\uffff\1\141\2\60\1\164\2\uffff\1\151\1\157"+
        "\1\156\1\60\1\uffff";
    static final String DFA6_maxS =
        "\1\172\1\162\1\75\1\145\1\uffff\1\76\1\157\1\56\1\156\1\uffff\1"+
        "\165\1\75\1\155\3\uffff\1\157\1\146\1\uffff\1\162\4\uffff\1\162"+
        "\1\uffff\1\163\1\141\1\150\4\uffff\1\162\2\uffff\1\147\3\uffff\1"+
        "\172\2\uffff\1\163\1\144\1\156\1\154\2\uffff\1\172\1\160\1\164\1"+
        "\172\1\157\1\145\1\165\1\145\1\162\1\151\1\141\1\151\1\uffff\1\145"+
        "\1\172\1\143\1\163\1\uffff\1\154\1\172\1\uffff\1\147\1\156\1\145"+
        "\1\163\1\172\1\154\1\171\1\156\1\172\1\uffff\1\164\2\145\1\uffff"+
        "\1\145\1\162\3\172\1\uffff\1\145\2\172\1\uffff\1\151\1\172\1\155"+
        "\1\144\1\141\3\uffff\1\172\2\uffff\1\157\1\145\1\165\1\155\1\uffff"+
        "\2\156\1\162\2\172\1\164\1\145\1\uffff\1\154\1\uffff\1\141\2\172"+
        "\1\164\2\uffff\1\151\1\157\1\156\1\172\1\uffff";
    static final String DFA6_acceptS =
        "\4\uffff\1\5\4\uffff\1\13\3\uffff\1\22\1\23\1\26\2\uffff\1\31\1"+
        "\uffff\1\34\1\35\1\36\1\37\1\uffff\1\41\3\uffff\1\46\1\50\1\51\1"+
        "\52\1\uffff\1\2\1\4\1\uffff\1\6\1\24\1\25\1\uffff\1\42\1\10\4\uffff"+
        "\1\16\1\17\14\uffff\1\7\4\uffff\1\20\2\uffff\1\30\11\uffff\1\12"+
        "\3\uffff\1\27\5\uffff\1\44\3\uffff\1\11\5\uffff\1\40\1\47\1\43\1"+
        "\uffff\1\1\1\3\4\uffff\1\45\7\uffff\1\33\1\uffff\1\14\4\uffff\1"+
        "\32\1\15\4\uffff\1\21";
    static final String DFA6_specialS =
        "\u0083\uffff}>";
    static final String[] DFA6_transitionS = {
            "\2\35\1\uffff\2\35\22\uffff\1\35\1\uffff\1\40\5\uffff\1\16\1"+
            "\25\1\31\1\22\1\4\1\17\1\7\1\27\12\37\1\2\1\26\1\5\1\11\1\13"+
            "\2\uffff\32\36\1\15\1\uffff\1\24\3\uffff\1\1\1\3\1\36\1\6\1"+
            "\10\1\12\2\36\1\14\4\36\1\20\1\21\1\23\3\36\1\30\1\32\1\33\1"+
            "\34\3\36",
            "\1\41",
            "\1\42",
            "\1\44",
            "",
            "\1\46\1\45",
            "\1\50",
            "\1\51",
            "\1\53\1\uffff\1\54",
            "",
            "\1\56\23\uffff\1\55",
            "\1\57",
            "\1\61\6\uffff\1\62",
            "",
            "",
            "",
            "\1\63",
            "\1\64",
            "",
            "\1\65",
            "",
            "",
            "",
            "",
            "\1\66\11\uffff\1\67",
            "",
            "\1\70",
            "\1\71",
            "\1\72",
            "",
            "",
            "",
            "",
            "\1\73",
            "",
            "",
            "\1\74",
            "",
            "",
            "",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "",
            "",
            "\1\76",
            "\1\77",
            "\1\100",
            "\1\101",
            "",
            "",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\1\103",
            "\1\104",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\1\106",
            "\1\107",
            "\1\110",
            "\1\111",
            "\1\112",
            "\1\113",
            "\1\114",
            "\1\115",
            "",
            "\1\116",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\1\120",
            "\1\121",
            "",
            "\1\122",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "",
            "\1\124\3\uffff\1\125",
            "\1\126",
            "\1\127",
            "\1\130",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\1\132",
            "\1\133",
            "\1\134",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "",
            "\1\136",
            "\1\137",
            "\1\140",
            "",
            "\1\141",
            "\1\142",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "",
            "\1\146",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "",
            "\1\151",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\1\152",
            "\1\153",
            "\1\154",
            "",
            "",
            "",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "",
            "",
            "\1\156",
            "\1\157",
            "\1\160",
            "\1\161",
            "",
            "\1\162",
            "\1\163",
            "\1\164",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\12\36\7\uffff\32\36\6\uffff\1\166\31\36",
            "\1\170",
            "\1\171",
            "",
            "\1\172",
            "",
            "\1\173",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            "\1\176",
            "",
            "",
            "\1\177",
            "\1\u0080",
            "\1\u0081",
            "\12\36\7\uffff\32\36\6\uffff\32\36",
            ""
    };

    static final short[] DFA6_eot = DFA.unpackEncodedString(DFA6_eotS);
    static final short[] DFA6_eof = DFA.unpackEncodedString(DFA6_eofS);
    static final char[] DFA6_min = DFA.unpackEncodedStringToUnsignedChars(DFA6_minS);
    static final char[] DFA6_max = DFA.unpackEncodedStringToUnsignedChars(DFA6_maxS);
    static final short[] DFA6_accept = DFA.unpackEncodedString(DFA6_acceptS);
    static final short[] DFA6_special = DFA.unpackEncodedString(DFA6_specialS);
    static final short[][] DFA6_transition;

    static {
        int numStates = DFA6_transitionS.length;
        DFA6_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA6_transition[i] = DFA.unpackEncodedString(DFA6_transitionS[i]);
        }
    }

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = DFA6_eot;
            this.eof = DFA6_eof;
            this.min = DFA6_min;
            this.max = DFA6_max;
            this.accept = DFA6_accept;
            this.special = DFA6_special;
            this.transition = DFA6_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( ARRAY | ASSIGN | BEGIN | COLON | COMMA | DIFFERENT | DO | DOT | ELSE | END | EQUALS | FUNCTION | FUNCTIONAL | GET | GT | IF | IMPLEMENTATION | LEFT_BRACKET | LEFT_PARENTESIS | LET | LT | MINUS | NOT | OF | PLUS | PROCEDURE | PROGRAM | RIGHT_BRACKET | RIGHT_PARENTESIS | SEMICOLON | SLASH | THEN | TIMES | TWO_DOTS | USES | VAR | WHILE | WHITESPACE | BOOLEAN | IDENT | NUMBER | STRING );";
        }
    }
 

}