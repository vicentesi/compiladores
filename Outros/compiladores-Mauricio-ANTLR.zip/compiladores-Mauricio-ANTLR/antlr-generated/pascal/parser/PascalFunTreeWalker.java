// $ANTLR 3.4 /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g 2013-02-22 00:04:59

package pascal.parser;

import pascal.parser.semantic.*;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.stringtemplate.*;
import org.antlr.stringtemplate.language.*;
import java.util.HashMap;
@SuppressWarnings({"all", "warnings", "unchecked"})
public class PascalFunTreeWalker extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ARRAY", "ASSIGN", "BEGIN", "BOOLEAN", "CALL", "COLON", "COMMA", "DIFFERENT", "DIGIT", "DO", "DOT", "ELSE", "END", "EQUALS", "FUNCTION", "FUNCTIONAL", "FUNCTIONAL_PARAM", "GET", "GT", "IDENT", "IF", "IMPLEMENTATION", "LEFT_BRACKET", "LEFT_PARENTESIS", "LET", "LETTER", "LT", "MINUS", "NOT", "NUMBER", "OF", "PARAM", "PLUS", "PROCEDURE", "PROGRAM", "RIGHT_BRACKET", "RIGHT_PARENTESIS", "SEMICOLON", "SLASH", "STM_LIST", "STRING", "THEN", "TIMES", "TWO_DOTS", "USES", "VAR", "WHILE", "WHITESPACE"
    };

    public static final int EOF=-1;
    public static final int ARRAY=4;
    public static final int ASSIGN=5;
    public static final int BEGIN=6;
    public static final int BOOLEAN=7;
    public static final int CALL=8;
    public static final int COLON=9;
    public static final int COMMA=10;
    public static final int DIFFERENT=11;
    public static final int DIGIT=12;
    public static final int DO=13;
    public static final int DOT=14;
    public static final int ELSE=15;
    public static final int END=16;
    public static final int EQUALS=17;
    public static final int FUNCTION=18;
    public static final int FUNCTIONAL=19;
    public static final int FUNCTIONAL_PARAM=20;
    public static final int GET=21;
    public static final int GT=22;
    public static final int IDENT=23;
    public static final int IF=24;
    public static final int IMPLEMENTATION=25;
    public static final int LEFT_BRACKET=26;
    public static final int LEFT_PARENTESIS=27;
    public static final int LET=28;
    public static final int LETTER=29;
    public static final int LT=30;
    public static final int MINUS=31;
    public static final int NOT=32;
    public static final int NUMBER=33;
    public static final int OF=34;
    public static final int PARAM=35;
    public static final int PLUS=36;
    public static final int PROCEDURE=37;
    public static final int PROGRAM=38;
    public static final int RIGHT_BRACKET=39;
    public static final int RIGHT_PARENTESIS=40;
    public static final int SEMICOLON=41;
    public static final int SLASH=42;
    public static final int STM_LIST=43;
    public static final int STRING=44;
    public static final int THEN=45;
    public static final int TIMES=46;
    public static final int TWO_DOTS=47;
    public static final int USES=48;
    public static final int VAR=49;
    public static final int WHILE=50;
    public static final int WHITESPACE=51;

    // delegates
    public TreeParser[] getDelegates() {
        return new TreeParser[] {};
    }

    // delegators


    public PascalFunTreeWalker(TreeNodeStream input) {
        this(input, new RecognizerSharedState());
    }
    public PascalFunTreeWalker(TreeNodeStream input, RecognizerSharedState state) {
        super(input, state);
    }

protected StringTemplateGroup templateLib =
  new StringTemplateGroup("PascalFunTreeWalkerTemplates", AngleBracketTemplateLexer.class);

public void setTemplateLib(StringTemplateGroup templateLib) {
  this.templateLib = templateLib;
}
public StringTemplateGroup getTemplateLib() {
  return templateLib;
}
/** allows convenient multi-value initialization:
 *  "new STAttrMap().put(...).put(...)"
 */
public static class STAttrMap extends HashMap {
  public STAttrMap put(String attrName, Object value) {
    super.put(attrName, value);
    return this;
  }
  public STAttrMap put(String attrName, int value) {
    super.put(attrName, new Integer(value));
    return this;
  }
}
    public String[] getTokenNames() { return PascalFunTreeWalker.tokenNames; }
    public String getGrammarFileName() { return "/home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g"; }


    GlobalScope globalScope;
    Scope currentScope;
    Function currentFunction;

    public PascalFunTreeWalker(TreeNodeStream input, Object dummyParam) {
      this(input);
      this.globalScope = new GlobalScope();
      this.currentScope = this.globalScope;
    }


    public static class program_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "program"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:29:1: program : ^( PROGRAM n= IDENT ^( USES (u+= use )+ ) ^( IMPLEMENTATION ( implementation )* ) EOF ) -> program(name=$nuses=$u);
    public final PascalFunTreeWalker.program_return program() throws RecognitionException {
        PascalFunTreeWalker.program_return retval = new PascalFunTreeWalker.program_return();
        retval.start = input.LT(1);


        PascalTree n=null;
        List list_u=null;
        RuleReturnScope u = null;
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:30:3: ( ^( PROGRAM n= IDENT ^( USES (u+= use )+ ) ^( IMPLEMENTATION ( implementation )* ) EOF ) -> program(name=$nuses=$u))
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:31:3: ^( PROGRAM n= IDENT ^( USES (u+= use )+ ) ^( IMPLEMENTATION ( implementation )* ) EOF )
            {
            match(input,PROGRAM,FOLLOW_PROGRAM_in_program88); 

            match(input, Token.DOWN, null); 
            n=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_program92); 

            match(input,USES,FOLLOW_USES_in_program99); 

            match(input, Token.DOWN, null); 
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:33:13: (u+= use )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==IDENT) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:33:13: u+= use
            	    {
            	    pushFollow(FOLLOW_use_in_program103);
            	    u=use();

            	    state._fsp--;

            	    if (list_u==null) list_u=new ArrayList();
            	    list_u.add(u.getTemplate());


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            match(input, Token.UP, null); 


            match(input,IMPLEMENTATION,FOLLOW_IMPLEMENTATION_in_program112); 

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); 
                // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:34:22: ( implementation )*
                loop2:
                do {
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( ((LA2_0 >= FUNCTION && LA2_0 <= FUNCTIONAL)||LA2_0==PROCEDURE||LA2_0==VAR) ) {
                        alt2=1;
                    }


                    switch (alt2) {
                	case 1 :
                	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:34:22: implementation
                	    {
                	    pushFollow(FOLLOW_implementation_in_program114);
                	    implementation();

                	    state._fsp--;


                	    }
                	    break;

                	default :
                	    break loop2;
                    }
                } while (true);


                match(input, Token.UP, null); 
            }


            match(input,EOF,FOLLOW_EOF_in_program122); 

            match(input, Token.UP, null); 


            // TEMPLATE REWRITE
            // 36:6: -> program(name=$nuses=$u)
            {
                retval.st = templateLib.getInstanceOf("program",new STAttrMap().put("name", n).put("uses", list_u));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "program"


    public static class use_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "use"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:39:1: use : i1= IDENT -> use(name=$i1);
    public final PascalFunTreeWalker.use_return use() throws RecognitionException {
        PascalFunTreeWalker.use_return retval = new PascalFunTreeWalker.use_return();
        retval.start = input.LT(1);


        PascalTree i1=null;

        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:40:3: (i1= IDENT -> use(name=$i1))
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:41:3: i1= IDENT
            {
            i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_use158); 


                       this.globalScope.addUse(i1);
                      

            // TEMPLATE REWRITE
            // 45:11: -> use(name=$i1)
            {
                retval.st = templateLib.getInstanceOf("use",new STAttrMap().put("name", i1));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "use"


    public static class implementation_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "implementation"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:48:1: implementation : ( ^( PROCEDURE name= IDENT ( ^( PARAM (p+= param )+ ) )? ( ^( VAR (v+= var )+ ) )? c= cmd ) -> procedure(name=$nameparams=$pvars=$vcmd=$c.st)| ^( FUNCTION name= IDENT ( ^( PARAM (p+= param )+ ) )? i2= IDENT ( ^( VAR (v+= var )+ ) )? c= cmd ) -> function(name=$nameparams=$preturn=$i2vars=$vcmd=$c.st)| ^( FUNCTIONAL name= IDENT ( ^( FUNCTIONAL_PARAM (p+= param_expr )+ ) )? i1= IDENT e1= expr ) -> functional(name=$nameparams=$preturn=$i1expr=$e1.st)| ^( VAR (v+= var )+ ) -> var(vars=$v));
    public final PascalFunTreeWalker.implementation_return implementation() throws RecognitionException {
        PascalFunTreeWalker.implementation_return retval = new PascalFunTreeWalker.implementation_return();
        retval.start = input.LT(1);


        PascalTree name=null;
        PascalTree i2=null;
        PascalTree i1=null;
        List list_p=null;
        List list_v=null;
        PascalFunTreeWalker.cmd_return c =null;

        PascalFunTreeWalker.expr_return e1 =null;

        RuleReturnScope p = null;
        RuleReturnScope v = null;
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:49:3: ( ^( PROCEDURE name= IDENT ( ^( PARAM (p+= param )+ ) )? ( ^( VAR (v+= var )+ ) )? c= cmd ) -> procedure(name=$nameparams=$pvars=$vcmd=$c.st)| ^( FUNCTION name= IDENT ( ^( PARAM (p+= param )+ ) )? i2= IDENT ( ^( VAR (v+= var )+ ) )? c= cmd ) -> function(name=$nameparams=$preturn=$i2vars=$vcmd=$c.st)| ^( FUNCTIONAL name= IDENT ( ^( FUNCTIONAL_PARAM (p+= param_expr )+ ) )? i1= IDENT e1= expr ) -> functional(name=$nameparams=$preturn=$i1expr=$e1.st)| ^( VAR (v+= var )+ ) -> var(vars=$v))
            int alt14=4;
            switch ( input.LA(1) ) {
            case PROCEDURE:
                {
                alt14=1;
                }
                break;
            case FUNCTION:
                {
                alt14=2;
                }
                break;
            case FUNCTIONAL:
                {
                alt14=3;
                }
                break;
            case VAR:
                {
                alt14=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;

            }

            switch (alt14) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:50:3: ^( PROCEDURE name= IDENT ( ^( PARAM (p+= param )+ ) )? ( ^( VAR (v+= var )+ ) )? c= cmd )
                    {
                    match(input,PROCEDURE,FOLLOW_PROCEDURE_in_implementation211); 

                    match(input, Token.DOWN, null); 
                    name=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_implementation215); 


                                             this.currentFunction = new Function(name, false, false);
                                             this.globalScope.addFunction(this.currentFunction);
                                             this.currentScope = new Scope(this.currentScope, false);
                                            

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:57:5: ( ^( PARAM (p+= param )+ ) )?
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==PARAM) ) {
                        alt4=1;
                    }
                    switch (alt4) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:58:7: ^( PARAM (p+= param )+ )
                            {
                            match(input,PARAM,FOLLOW_PARAM_in_implementation257); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:58:16: (p+= param )+
                            int cnt3=0;
                            loop3:
                            do {
                                int alt3=2;
                                int LA3_0 = input.LA(1);

                                if ( (LA3_0==IDENT) ) {
                                    alt3=1;
                                }


                                switch (alt3) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:58:16: p+= param
                            	    {
                            	    pushFollow(FOLLOW_param_in_implementation261);
                            	    p=param();

                            	    state._fsp--;

                            	    if (list_p==null) list_p=new ArrayList();
                            	    list_p.add(p.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt3 >= 1 ) break loop3;
                                        EarlyExitException eee =
                                            new EarlyExitException(3, input);
                                        throw eee;
                                }
                                cnt3++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }


                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:60:5: ( ^( VAR (v+= var )+ ) )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==VAR) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:61:7: ^( VAR (v+= var )+ )
                            {
                            match(input,VAR,FOLLOW_VAR_in_implementation285); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:61:14: (v+= var )+
                            int cnt5=0;
                            loop5:
                            do {
                                int alt5=2;
                                int LA5_0 = input.LA(1);

                                if ( (LA5_0==IDENT) ) {
                                    alt5=1;
                                }


                                switch (alt5) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:61:14: v+= var
                            	    {
                            	    pushFollow(FOLLOW_var_in_implementation289);
                            	    v=var();

                            	    state._fsp--;

                            	    if (list_v==null) list_v=new ArrayList();
                            	    list_v.add(v.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt5 >= 1 ) break loop5;
                                        EarlyExitException eee =
                                            new EarlyExitException(5, input);
                                        throw eee;
                                }
                                cnt5++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }


                    pushFollow(FOLLOW_cmd_in_implementation306);
                    c=cmd();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       this.currentFunction = null;
                       this.currentScope = this.currentScope.getParentScope();
                      

                    // TEMPLATE REWRITE
                    // 69:3: -> procedure(name=$nameparams=$pvars=$vcmd=$c.st)
                    {
                        retval.st = templateLib.getInstanceOf("procedure",new STAttrMap().put("name", name).put("params", list_p).put("vars", list_v).put("cmd", (c!=null?c.st:null)));
                    }



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:72:3: ^( FUNCTION name= IDENT ( ^( PARAM (p+= param )+ ) )? i2= IDENT ( ^( VAR (v+= var )+ ) )? c= cmd )
                    {
                    match(input,FUNCTION,FOLLOW_FUNCTION_in_implementation361); 

                    match(input, Token.DOWN, null); 
                    name=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_implementation365); 


                                            this.currentFunction = new Function(name, false, true);
                                            this.globalScope.addFunction(this.currentFunction);
                                            this.currentScope = new Scope(this.currentScope, true);
                                           

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:79:5: ( ^( PARAM (p+= param )+ ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==PARAM) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:80:7: ^( PARAM (p+= param )+ )
                            {
                            match(input,PARAM,FOLLOW_PARAM_in_implementation406); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:80:16: (p+= param )+
                            int cnt7=0;
                            loop7:
                            do {
                                int alt7=2;
                                int LA7_0 = input.LA(1);

                                if ( (LA7_0==IDENT) ) {
                                    alt7=1;
                                }


                                switch (alt7) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:80:16: p+= param
                            	    {
                            	    pushFollow(FOLLOW_param_in_implementation410);
                            	    p=param();

                            	    state._fsp--;

                            	    if (list_p==null) list_p=new ArrayList();
                            	    list_p.add(p.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt7 >= 1 ) break loop7;
                                        EarlyExitException eee =
                                            new EarlyExitException(7, input);
                                        throw eee;
                                }
                                cnt7++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }


                    i2=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_implementation427); 


                                 Symbol s = new Symbol();
                                 s.type = new Type();
                                 s.type.name = (i2!=null?i2.getText():null);
                                 this.currentScope.addSymbol("result", s);
                                 this.currentFunction.setType(s.type);
                                

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:90:5: ( ^( VAR (v+= var )+ ) )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==VAR) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:91:7: ^( VAR (v+= var )+ )
                            {
                            match(input,VAR,FOLLOW_VAR_in_implementation457); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:91:14: (v+= var )+
                            int cnt9=0;
                            loop9:
                            do {
                                int alt9=2;
                                int LA9_0 = input.LA(1);

                                if ( (LA9_0==IDENT) ) {
                                    alt9=1;
                                }


                                switch (alt9) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:91:14: v+= var
                            	    {
                            	    pushFollow(FOLLOW_var_in_implementation461);
                            	    v=var();

                            	    state._fsp--;

                            	    if (list_v==null) list_v=new ArrayList();
                            	    list_v.add(v.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt9 >= 1 ) break loop9;
                                        EarlyExitException eee =
                                            new EarlyExitException(9, input);
                                        throw eee;
                                }
                                cnt9++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }


                    pushFollow(FOLLOW_cmd_in_implementation478);
                    c=cmd();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       this.currentFunction = null;
                       this.currentScope = this.currentScope.getParentScope();
                      

                    // TEMPLATE REWRITE
                    // 99:3: -> function(name=$nameparams=$preturn=$i2vars=$vcmd=$c.st)
                    {
                        retval.st = templateLib.getInstanceOf("function",new STAttrMap().put("name", name).put("params", list_p).put("return", i2).put("vars", list_v).put("cmd", (c!=null?c.st:null)));
                    }



                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:102:3: ^( FUNCTIONAL name= IDENT ( ^( FUNCTIONAL_PARAM (p+= param_expr )+ ) )? i1= IDENT e1= expr )
                    {
                    match(input,FUNCTIONAL,FOLLOW_FUNCTIONAL_in_implementation538); 

                    match(input, Token.DOWN, null); 
                    name=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_implementation542); 


                                              this.currentFunction = new Function(name, true, true);
                                              this.globalScope.addFunction(this.currentFunction);
                                              this.currentScope = new Scope(this.currentScope, false);
                                             

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:109:5: ( ^( FUNCTIONAL_PARAM (p+= param_expr )+ ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==FUNCTIONAL_PARAM) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:110:7: ^( FUNCTIONAL_PARAM (p+= param_expr )+ )
                            {
                            match(input,FUNCTIONAL_PARAM,FOLLOW_FUNCTIONAL_PARAM_in_implementation585); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:110:27: (p+= param_expr )+
                            int cnt11=0;
                            loop11:
                            do {
                                int alt11=2;
                                int LA11_0 = input.LA(1);

                                if ( ((LA11_0 >= BOOLEAN && LA11_0 <= CALL)||LA11_0==IDENT||(LA11_0 >= MINUS && LA11_0 <= NUMBER)||LA11_0==PLUS||LA11_0==SLASH||LA11_0==STRING||LA11_0==TIMES) ) {
                                    alt11=1;
                                }


                                switch (alt11) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:110:27: p+= param_expr
                            	    {
                            	    pushFollow(FOLLOW_param_expr_in_implementation589);
                            	    p=param_expr();

                            	    state._fsp--;

                            	    if (list_p==null) list_p=new ArrayList();
                            	    list_p.add(p.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt11 >= 1 ) break loop11;
                                        EarlyExitException eee =
                                            new EarlyExitException(11, input);
                                        throw eee;
                                }
                                cnt11++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }


                    i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_implementation606); 

                    pushFollow(FOLLOW_expr_in_implementation610);
                    e1=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       Type t = new Type();
                       t.name = (i1!=null?i1.getText():null);
                       this.currentFunction.setType(t);
                       this.currentFunction = null;
                       this.currentScope = this.currentScope.getParentScope();
                       System.out.println("Functional " + (name!=null?name.getText():null) + " parsed");
                      

                    // TEMPLATE REWRITE
                    // 122:3: -> functional(name=$nameparams=$preturn=$i1expr=$e1.st)
                    {
                        retval.st = templateLib.getInstanceOf("functional",new STAttrMap().put("name", name).put("params", list_p).put("return", i1).put("expr", (e1!=null?e1.st:null)));
                    }



                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:125:3: ^( VAR (v+= var )+ )
                    {
                    match(input,VAR,FOLLOW_VAR_in_implementation660); 

                    match(input, Token.DOWN, null); 
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:125:10: (v+= var )+
                    int cnt13=0;
                    loop13:
                    do {
                        int alt13=2;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0==IDENT) ) {
                            alt13=1;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:125:10: v+= var
                    	    {
                    	    pushFollow(FOLLOW_var_in_implementation664);
                    	    v=var();

                    	    state._fsp--;

                    	    if (list_v==null) list_v=new ArrayList();
                    	    list_v.add(v.getTemplate());


                    	    }
                    	    break;

                    	default :
                    	    if ( cnt13 >= 1 ) break loop13;
                                EarlyExitException eee =
                                    new EarlyExitException(13, input);
                                throw eee;
                        }
                        cnt13++;
                    } while (true);


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 126:3: -> var(vars=$v)
                    {
                        retval.st = templateLib.getInstanceOf("var",new STAttrMap().put("vars", list_v));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "implementation"


    public static class param_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "param"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:130:1: param : name= IDENT t= type -> param(name=$nametype=$t.st);
    public final PascalFunTreeWalker.param_return param() throws RecognitionException {
        PascalFunTreeWalker.param_return retval = new PascalFunTreeWalker.param_return();
        retval.start = input.LT(1);


        PascalTree name=null;
        PascalFunTreeWalker.type_return t =null;


        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:131:3: (name= IDENT t= type -> param(name=$nametype=$t.st))
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:132:3: name= IDENT t= type
            {
            name=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_param700); 

            pushFollow(FOLLOW_type_in_param704);
            t=type();

            state._fsp--;



                                PascalTree t1 = (t!=null?((PascalTree)t.start):null);
                                name.symbol.type = t1.symbol.type;
                                this.currentScope.addSymbol(name);
                               

            // TEMPLATE REWRITE
            // 138:7: -> param(name=$nametype=$t.st)
            {
                retval.st = templateLib.getInstanceOf("param",new STAttrMap().put("name", name).put("type", (t!=null?t.st:null)));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "param"


    public static class cond_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "cond"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:142:1: cond : ( ^(p= EQUALS e1= expr e2= expr ) -> eq(e1=$e1.ste2=$e2.st)| ^(p= DIFFERENT e1= expr e2= expr ) -> neq(e1=$e1.ste2=$e2.st)| ^(p= LET e1= expr e2= expr ) -> let(e1=$e1.ste2=$e2.st)| ^(p= GET e1= expr e2= expr ) -> get(e1=$e1.ste2=$e2.st)| ^(p= GT e1= expr e2= expr ) -> gt(e1=$e1.ste2=$e2.st)| ^(p= LT e1= expr e2= expr ) -> lt(e1=$e1.ste2=$e2.st));
    public final PascalFunTreeWalker.cond_return cond() throws RecognitionException {
        PascalFunTreeWalker.cond_return retval = new PascalFunTreeWalker.cond_return();
        retval.start = input.LT(1);


        PascalTree p=null;
        PascalFunTreeWalker.expr_return e1 =null;

        PascalFunTreeWalker.expr_return e2 =null;


        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:143:3: ( ^(p= EQUALS e1= expr e2= expr ) -> eq(e1=$e1.ste2=$e2.st)| ^(p= DIFFERENT e1= expr e2= expr ) -> neq(e1=$e1.ste2=$e2.st)| ^(p= LET e1= expr e2= expr ) -> let(e1=$e1.ste2=$e2.st)| ^(p= GET e1= expr e2= expr ) -> get(e1=$e1.ste2=$e2.st)| ^(p= GT e1= expr e2= expr ) -> gt(e1=$e1.ste2=$e2.st)| ^(p= LT e1= expr e2= expr ) -> lt(e1=$e1.ste2=$e2.st))
            int alt15=6;
            switch ( input.LA(1) ) {
            case EQUALS:
                {
                alt15=1;
                }
                break;
            case DIFFERENT:
                {
                alt15=2;
                }
                break;
            case LET:
                {
                alt15=3;
                }
                break;
            case GET:
                {
                alt15=4;
                }
                break;
            case GT:
                {
                alt15=5;
                }
                break;
            case LT:
                {
                alt15=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;

            }

            switch (alt15) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:144:3: ^(p= EQUALS e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,EQUALS,FOLLOW_EQUALS_in_cond774); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_cond778);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_cond782);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       if (!Type.equals(e1.ret, e2.ret)) {
                          System.err.println("Line:"+(p!=null?p.getLine():0)+":Invalid types.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 150:5: -> eq(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("eq",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:153:3: ^(p= DIFFERENT e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,DIFFERENT,FOLLOW_DIFFERENT_in_cond824); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_cond828);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_cond832);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       if (!Type.different(e1.ret, e2.ret)) {
                          System.err.println("Line:"+(p!=null?p.getLine():0)+":Invalid types.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 159:3: -> neq(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("neq",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:162:3: ^(p= LET e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,LET,FOLLOW_LET_in_cond872); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_cond876);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_cond880);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       if (!Type.lessEqualThan(e1.ret, e2.ret)) {
                          System.err.println("Line:"+(p!=null?p.getLine():0)+":Invalid types.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 168:3: -> let(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("let",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:171:3: ^(p= GET e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,GET,FOLLOW_GET_in_cond920); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_cond924);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_cond928);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       if (!Type.greatEqualThan(e1.ret, e2.ret)) {
                          System.err.println("Line:"+(p!=null?p.getLine():0)+":Invalid types.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 177:3: -> get(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("get",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 5 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:180:3: ^(p= GT e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,GT,FOLLOW_GT_in_cond968); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_cond972);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_cond976);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       if (!Type.greaterThan(e1.ret, e2.ret)) {
                          System.err.println("Line:"+(p!=null?p.getLine():0)+":Invalid types.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 186:3: -> gt(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("gt",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 6 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:189:3: ^(p= LT e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,LT,FOLLOW_LT_in_cond1016); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_cond1020);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_cond1024);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       if (!Type.lessThan(e1.ret, e2.ret)) {
                          System.err.println("Line:"+(p!=null?p.getLine():0)+":Invalid types.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 195:3: -> lt(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("lt",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "cond"


    public static class cmd_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "cmd"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:199:1: cmd : ( ^( STM_LIST (c+= cmd )* ) -> stm(cmd=$c)| ^( IF c1= cond c3= cmd ) -> if(cond=$c1.stcmd=$c3.st)| ^( WHILE c2= cond cmd2= cmd ) -> while(cond=$c2.stcmd=$cmd2.st)|exp1= expr -> expr(e=$exp1.st));
    public final PascalFunTreeWalker.cmd_return cmd() throws RecognitionException {
        PascalFunTreeWalker.cmd_return retval = new PascalFunTreeWalker.cmd_return();
        retval.start = input.LT(1);


        List list_c=null;
        PascalFunTreeWalker.cond_return c1 =null;

        PascalFunTreeWalker.cmd_return c3 =null;

        PascalFunTreeWalker.cond_return c2 =null;

        PascalFunTreeWalker.cmd_return cmd2 =null;

        PascalFunTreeWalker.expr_return exp1 =null;

        RuleReturnScope c = null;
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:200:3: ( ^( STM_LIST (c+= cmd )* ) -> stm(cmd=$c)| ^( IF c1= cond c3= cmd ) -> if(cond=$c1.stcmd=$c3.st)| ^( WHILE c2= cond cmd2= cmd ) -> while(cond=$c2.stcmd=$cmd2.st)|exp1= expr -> expr(e=$exp1.st))
            int alt17=4;
            switch ( input.LA(1) ) {
            case STM_LIST:
                {
                alt17=1;
                }
                break;
            case IF:
                {
                alt17=2;
                }
                break;
            case WHILE:
                {
                alt17=3;
                }
                break;
            case ASSIGN:
            case BOOLEAN:
            case CALL:
            case IDENT:
            case MINUS:
            case NOT:
            case NUMBER:
            case PLUS:
            case SLASH:
            case STRING:
            case TIMES:
                {
                alt17=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;

            }

            switch (alt17) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:201:3: ^( STM_LIST (c+= cmd )* )
                    {
                    match(input,STM_LIST,FOLLOW_STM_LIST_in_cmd1069); 

                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); 
                        // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:201:15: (c+= cmd )*
                        loop16:
                        do {
                            int alt16=2;
                            int LA16_0 = input.LA(1);

                            if ( (LA16_0==ASSIGN||(LA16_0 >= BOOLEAN && LA16_0 <= CALL)||(LA16_0 >= IDENT && LA16_0 <= IF)||(LA16_0 >= MINUS && LA16_0 <= NUMBER)||LA16_0==PLUS||(LA16_0 >= SLASH && LA16_0 <= STRING)||LA16_0==TIMES||LA16_0==WHILE) ) {
                                alt16=1;
                            }


                            switch (alt16) {
                        	case 1 :
                        	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:201:15: c+= cmd
                        	    {
                        	    pushFollow(FOLLOW_cmd_in_cmd1073);
                        	    c=cmd();

                        	    state._fsp--;

                        	    if (list_c==null) list_c=new ArrayList();
                        	    list_c.add(c.getTemplate());


                        	    }
                        	    break;

                        	default :
                        	    break loop16;
                            }
                        } while (true);


                        match(input, Token.UP, null); 
                    }


                    // TEMPLATE REWRITE
                    // 202:3: -> stm(cmd=$c)
                    {
                        retval.st = templateLib.getInstanceOf("stm",new STAttrMap().put("cmd", list_c));
                    }



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:205:3: ^( IF c1= cond c3= cmd )
                    {
                    match(input,IF,FOLLOW_IF_in_cmd1101); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_cond_in_cmd1105);
                    c1=cond();

                    state._fsp--;


                    pushFollow(FOLLOW_cmd_in_cmd1109);
                    c3=cmd();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 206:5: -> if(cond=$c1.stcmd=$c3.st)
                    {
                        retval.st = templateLib.getInstanceOf("if",new STAttrMap().put("cond", (c1!=null?c1.st:null)).put("cmd", (c3!=null?c3.st:null)));
                    }



                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:209:3: ^( WHILE c2= cond cmd2= cmd )
                    {
                    match(input,WHILE,FOLLOW_WHILE_in_cmd1141); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_cond_in_cmd1145);
                    c2=cond();

                    state._fsp--;


                    pushFollow(FOLLOW_cmd_in_cmd1149);
                    cmd2=cmd();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 210:5: -> while(cond=$c2.stcmd=$cmd2.st)
                    {
                        retval.st = templateLib.getInstanceOf("while",new STAttrMap().put("cond", (c2!=null?c2.st:null)).put("cmd", (cmd2!=null?cmd2.st:null)));
                    }



                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:212:5: exp1= expr
                    {
                    pushFollow(FOLLOW_expr_in_cmd1182);
                    exp1=expr();

                    state._fsp--;


                    // TEMPLATE REWRITE
                    // 213:5: -> expr(e=$exp1.st)
                    {
                        retval.st = templateLib.getInstanceOf("expr",new STAttrMap().put("e", (exp1!=null?exp1.st:null)));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "cmd"


    public static class expr_return extends TreeRuleReturnScope {
        public Type ret;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "expr"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:217:1: expr returns [Type ret] : ( ^(p= ASSIGN i1= IDENT e= expr ) -> assign(to=$i1e=$e.st)| ^(p= PLUS e1= expr e2= expr ) -> plus(e1=$e1.ste2=$e2.st)| ^(p= MINUS e1= expr e2= expr ) -> minus(e1=$e1.ste2=$e2.st)| ^(p= TIMES e1= expr e2= expr ) -> times(e1=$e1.ste2=$e2.st)| ^(p= SLASH e1= expr e2= expr ) -> slash(e1=$e1.ste2=$e2.st)| ^( CALL i1= IDENT ( ^( FUNCTIONAL_PARAM (expre+= expr )+ ) )? ) -> call(name=$i1params=$expre)| ^( NOT e= expr ) -> not(e=$e.st)|i= IDENT -> ident(i=$i)|n= NUMBER -> number(n=$n)|s= STRING -> string(s=$s)|b= BOOLEAN -> boolean(b=$b));
    public final PascalFunTreeWalker.expr_return expr() throws RecognitionException {
        PascalFunTreeWalker.expr_return retval = new PascalFunTreeWalker.expr_return();
        retval.start = input.LT(1);


        PascalTree p=null;
        PascalTree i1=null;
        PascalTree i=null;
        PascalTree n=null;
        PascalTree s=null;
        PascalTree b=null;
        List list_expre=null;
        PascalFunTreeWalker.expr_return e =null;

        PascalFunTreeWalker.expr_return e1 =null;

        PascalFunTreeWalker.expr_return e2 =null;

        RuleReturnScope expre = null;
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:218:3: ( ^(p= ASSIGN i1= IDENT e= expr ) -> assign(to=$i1e=$e.st)| ^(p= PLUS e1= expr e2= expr ) -> plus(e1=$e1.ste2=$e2.st)| ^(p= MINUS e1= expr e2= expr ) -> minus(e1=$e1.ste2=$e2.st)| ^(p= TIMES e1= expr e2= expr ) -> times(e1=$e1.ste2=$e2.st)| ^(p= SLASH e1= expr e2= expr ) -> slash(e1=$e1.ste2=$e2.st)| ^( CALL i1= IDENT ( ^( FUNCTIONAL_PARAM (expre+= expr )+ ) )? ) -> call(name=$i1params=$expre)| ^( NOT e= expr ) -> not(e=$e.st)|i= IDENT -> ident(i=$i)|n= NUMBER -> number(n=$n)|s= STRING -> string(s=$s)|b= BOOLEAN -> boolean(b=$b))
            int alt20=11;
            switch ( input.LA(1) ) {
            case ASSIGN:
                {
                alt20=1;
                }
                break;
            case PLUS:
                {
                alt20=2;
                }
                break;
            case MINUS:
                {
                alt20=3;
                }
                break;
            case TIMES:
                {
                alt20=4;
                }
                break;
            case SLASH:
                {
                alt20=5;
                }
                break;
            case CALL:
                {
                alt20=6;
                }
                break;
            case NOT:
                {
                alt20=7;
                }
                break;
            case IDENT:
                {
                alt20=8;
                }
                break;
            case NUMBER:
                {
                alt20=9;
                }
                break;
            case STRING:
                {
                alt20=10;
                }
                break;
            case BOOLEAN:
                {
                alt20=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;

            }

            switch (alt20) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:219:3: ^(p= ASSIGN i1= IDENT e= expr )
                    {
                    p=(PascalTree)match(input,ASSIGN,FOLLOW_ASSIGN_in_expr1223); 

                    match(input, Token.DOWN, null); 
                    i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_expr1227); 

                    pushFollow(FOLLOW_expr_in_expr1231);
                    e=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       Symbol s1 = this.currentScope.resolveSymbol((i1!=null?i1.getText():null));
                       if (s1 != null) {
                        retval.ret = s1.assign(e.ret);
                        if (retval.ret == null) {
                          System.err.println("Line:" +(p!=null?p.getLine():0)+ ":Invalid types on assign.");
                        }
                       }
                      

                    // TEMPLATE REWRITE
                    // 230:3: -> assign(to=$i1e=$e.st)
                    {
                        retval.st = templateLib.getInstanceOf("assign",new STAttrMap().put("to", i1).put("e", (e!=null?e.st:null)));
                    }



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:233:3: ^(p= PLUS e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,PLUS,FOLLOW_PLUS_in_expr1272); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1276);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_expr1280);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       retval.ret = Type.plus(e1.ret, e2.ret);
                       if (retval.ret == null) {
                        System.err.println("Line:" + (p!=null?p.getLine():0) + ": Invalid types on '+' operation.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 240:3: -> plus(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("plus",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:243:3: ^(p= MINUS e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,MINUS,FOLLOW_MINUS_in_expr1318); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1322);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_expr1326);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       retval.ret = Type.minus(e1.ret, e2.ret);
                       if (retval.ret == null) {
                        System.err.println("Line:" + (p!=null?p.getLine():0) + ":Invalid types on '-' operation.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 250:3: -> minus(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("minus",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:253:3: ^(p= TIMES e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,TIMES,FOLLOW_TIMES_in_expr1364); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1368);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_expr1372);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       retval.ret = Type.times(e1.ret, e2.ret);
                       if (retval.ret == null) {
                        System.err.println("Line:" + (p!=null?p.getLine():0) + ":Invalid types on '*' operation.");
                       }
                      

                    // TEMPLATE REWRITE
                    // 260:3: -> times(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("times",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 5 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:263:3: ^(p= SLASH e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,SLASH,FOLLOW_SLASH_in_expr1410); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1414);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_expr1418);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                         retval.ret = Type.slash(e1.ret, e2.ret);
                         if (retval.ret == null) {
                          System.err.println("Line:"+ (p!=null?p.getLine():0)+":Invalid types on '\' operation.");
                         }
                        

                    // TEMPLATE REWRITE
                    // 270:3: -> slash(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("slash",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 6 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:273:3: ^( CALL i1= IDENT ( ^( FUNCTIONAL_PARAM (expre+= expr )+ ) )? )
                    {
                    match(input,CALL,FOLLOW_CALL_in_expr1461); 

                    match(input, Token.DOWN, null); 
                    i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_expr1465); 

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:275:5: ( ^( FUNCTIONAL_PARAM (expre+= expr )+ ) )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==FUNCTIONAL_PARAM) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:276:7: ^( FUNCTIONAL_PARAM (expre+= expr )+ )
                            {
                            match(input,FUNCTIONAL_PARAM,FOLLOW_FUNCTIONAL_PARAM_in_expr1480); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:276:31: (expre+= expr )+
                            int cnt18=0;
                            loop18:
                            do {
                                int alt18=2;
                                int LA18_0 = input.LA(1);

                                if ( (LA18_0==ASSIGN||(LA18_0 >= BOOLEAN && LA18_0 <= CALL)||LA18_0==IDENT||(LA18_0 >= MINUS && LA18_0 <= NUMBER)||LA18_0==PLUS||LA18_0==SLASH||LA18_0==STRING||LA18_0==TIMES) ) {
                                    alt18=1;
                                }


                                switch (alt18) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:276:31: expre+= expr
                            	    {
                            	    pushFollow(FOLLOW_expr_in_expr1484);
                            	    expre=expr();

                            	    state._fsp--;

                            	    if (list_expre==null) list_expre=new ArrayList();
                            	    list_expre.add(expre.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt18 >= 1 ) break loop18;
                                        EarlyExitException eee =
                                            new EarlyExitException(18, input);
                                        throw eee;
                                }
                                cnt18++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }


                    match(input, Token.UP, null); 



                       retval.ret = this.globalScope.resolveFunction((i1!=null?i1.getText():null));
                      

                    // TEMPLATE REWRITE
                    // 282:3: -> call(name=$i1params=$expre)
                    {
                        retval.st = templateLib.getInstanceOf("call",new STAttrMap().put("name", i1).put("params", list_expre));
                    }



                    }
                    break;
                case 7 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:285:3: ^( NOT e= expr )
                    {
                    match(input,NOT,FOLLOW_NOT_in_expr1531); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_expr1535);
                    e=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       retval.ret = e.ret;
                      

                    // TEMPLATE REWRITE
                    // 289:3: -> not(e=$e.st)
                    {
                        retval.st = templateLib.getInstanceOf("not",new STAttrMap().put("e", (e!=null?e.st:null)));
                    }



                    }
                    break;
                case 8 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:291:5: i= IDENT
                    {
                    i=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_expr1563); 


                                retval.ret = this.currentScope.resolveSymbol((i!=null?i.getText():null)).type;
                               

                    // TEMPLATE REWRITE
                    // 295:3: -> ident(i=$i)
                    {
                        retval.st = templateLib.getInstanceOf("ident",new STAttrMap().put("i", i));
                    }



                    }
                    break;
                case 9 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:297:5: n= NUMBER
                    {
                    n=(PascalTree)match(input,NUMBER,FOLLOW_NUMBER_in_expr1600); 


                               retval.ret = new Type();
                               retval.ret.name = "integer";
                              

                    // TEMPLATE REWRITE
                    // 302:3: -> number(n=$n)
                    {
                        retval.st = templateLib.getInstanceOf("number",new STAttrMap().put("n", n));
                    }



                    }
                    break;
                case 10 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:304:5: s= STRING
                    {
                    s=(PascalTree)match(input,STRING,FOLLOW_STRING_in_expr1636); 


                               retval.ret = new Type();
                               retval.ret.name = "string";
                              

                    // TEMPLATE REWRITE
                    // 309:3: -> string(s=$s)
                    {
                        retval.st = templateLib.getInstanceOf("string",new STAttrMap().put("s", s));
                    }



                    }
                    break;
                case 11 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:311:5: b= BOOLEAN
                    {
                    b=(PascalTree)match(input,BOOLEAN,FOLLOW_BOOLEAN_in_expr1672); 


                                retval.ret = new Type();
                                retval.ret.name = "boolean";
                               

                    // TEMPLATE REWRITE
                    // 316:3: -> boolean(b=$b)
                    {
                        retval.st = templateLib.getInstanceOf("boolean",new STAttrMap().put("b", b));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "expr"


    public static class var_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "var"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:320:1: var : i1= IDENT t= type -> var(name=$i1type=$t.st);
    public final PascalFunTreeWalker.var_return var() throws RecognitionException {
        PascalFunTreeWalker.var_return retval = new PascalFunTreeWalker.var_return();
        retval.start = input.LT(1);


        PascalTree i1=null;
        PascalFunTreeWalker.type_return t =null;


        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:321:3: (i1= IDENT t= type -> var(name=$i1type=$t.st))
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:322:3: i1= IDENT t= type
            {
            i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_var1720); 

            pushFollow(FOLLOW_type_in_var1724);
            t=type();

            state._fsp--;



                              PascalTree var = i1;
                              var.symbol.type = (t!=null?t.ret:null);
                              this.currentScope.addSymbol(var);
                             

            // TEMPLATE REWRITE
            // 328:5: -> var(name=$i1type=$t.st)
            {
                retval.st = templateLib.getInstanceOf("var",new STAttrMap().put("name", i1).put("type", (t!=null?t.st:null)));
            }



            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "var"


    public static class type_return extends TreeRuleReturnScope {
        public Type ret;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "type"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:332:1: type returns [Type ret] : (i1= IDENT -> type(name=$i1)| ^( ARRAY n1= NUMBER n2= NUMBER t1= type ) -> typearray(n1=$n1n2=$n2type=$t1.st));
    public final PascalFunTreeWalker.type_return type() throws RecognitionException {
        PascalFunTreeWalker.type_return retval = new PascalFunTreeWalker.type_return();
        retval.start = input.LT(1);


        PascalTree i1=null;
        PascalTree n1=null;
        PascalTree n2=null;
        PascalFunTreeWalker.type_return t1 =null;


        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:333:3: (i1= IDENT -> type(name=$i1)| ^( ARRAY n1= NUMBER n2= NUMBER t1= type ) -> typearray(n1=$n1n2=$n2type=$t1.st))
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==IDENT) ) {
                alt21=1;
            }
            else if ( (LA21_0==ARRAY) ) {
                alt21=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;

            }
            switch (alt21) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:334:3: i1= IDENT
                    {
                    i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_type1791); 


                               retval.ret = new Type();
                               retval.ret.name = (i1!=null?i1.getText():null);
                              

                    // TEMPLATE REWRITE
                    // 339:3: -> type(name=$i1)
                    {
                        retval.st = templateLib.getInstanceOf("type",new STAttrMap().put("name", i1));
                    }



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:342:3: ^( ARRAY n1= NUMBER n2= NUMBER t1= type )
                    {
                    match(input,ARRAY,FOLLOW_ARRAY_in_type1828); 

                    match(input, Token.DOWN, null); 
                    n1=(PascalTree)match(input,NUMBER,FOLLOW_NUMBER_in_type1832); 

                    n2=(PascalTree)match(input,NUMBER,FOLLOW_NUMBER_in_type1836); 

                    pushFollow(FOLLOW_type_in_type1840);
                    t1=type();

                    state._fsp--;


                    match(input, Token.UP, null); 



                       retval.ret = new Type();
                                       retval.ret.isArray = true;
                                       retval.ret.begin = (n1!=null?Integer.valueOf(n1.getText()):0);
                                       retval.ret.end = (n2!=null?Integer.valueOf(n2.getText()):0);
                                       retval.ret.arrayOf = (t1!=null?t1.ret:null);
                      

                    // TEMPLATE REWRITE
                    // 350:5: -> typearray(n1=$n1n2=$n2type=$t1.st)
                    {
                        retval.st = templateLib.getInstanceOf("typearray",new STAttrMap().put("n1", n1).put("n2", n2).put("type", (t1!=null?t1.st:null)));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "type"


    public static class param_expr_return extends TreeRuleReturnScope {
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };


    // $ANTLR start "param_expr"
    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:354:1: param_expr : ( ^(p= PLUS e1= expr e2= expr ) -> paramplus(e1=$e1.ste2=$e2.st)| ^(p= MINUS e1= expr e2= expr ) -> paramminus(e1=$e1.ste2=$e2.st)| ^(p= TIMES e1= expr e2= expr ) -> paramtimes(e1=$e1.ste2=$e2.st)| ^(p= SLASH e1= expr e2= expr ) -> paramslash(e1=$e1.ste2=$e2.st)| ^( CALL i1= IDENT ( ^( FUNCTIONAL_PARAM (e+= expr )+ ) )? ) -> paramcall(cally=$i1e=$e)| ^( NOT ex= expr ) -> paramnot(e=$ex.st)|i= IDENT (t= type )? -> paramident(i=$i)|n= NUMBER -> paramnumber(n=$n)|s= STRING -> paramstring(s=$s)|b= BOOLEAN -> parambool(b=$b));
    public final PascalFunTreeWalker.param_expr_return param_expr() throws RecognitionException {
        PascalFunTreeWalker.param_expr_return retval = new PascalFunTreeWalker.param_expr_return();
        retval.start = input.LT(1);


        PascalTree p=null;
        PascalTree i1=null;
        PascalTree i=null;
        PascalTree n=null;
        PascalTree s=null;
        PascalTree b=null;
        List list_e=null;
        PascalFunTreeWalker.expr_return e1 =null;

        PascalFunTreeWalker.expr_return e2 =null;

        PascalFunTreeWalker.expr_return ex =null;

        PascalFunTreeWalker.type_return t =null;

        RuleReturnScope e = null;
        try {
            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:355:3: ( ^(p= PLUS e1= expr e2= expr ) -> paramplus(e1=$e1.ste2=$e2.st)| ^(p= MINUS e1= expr e2= expr ) -> paramminus(e1=$e1.ste2=$e2.st)| ^(p= TIMES e1= expr e2= expr ) -> paramtimes(e1=$e1.ste2=$e2.st)| ^(p= SLASH e1= expr e2= expr ) -> paramslash(e1=$e1.ste2=$e2.st)| ^( CALL i1= IDENT ( ^( FUNCTIONAL_PARAM (e+= expr )+ ) )? ) -> paramcall(cally=$i1e=$e)| ^( NOT ex= expr ) -> paramnot(e=$ex.st)|i= IDENT (t= type )? -> paramident(i=$i)|n= NUMBER -> paramnumber(n=$n)|s= STRING -> paramstring(s=$s)|b= BOOLEAN -> parambool(b=$b))
            int alt25=10;
            switch ( input.LA(1) ) {
            case PLUS:
                {
                alt25=1;
                }
                break;
            case MINUS:
                {
                alt25=2;
                }
                break;
            case TIMES:
                {
                alt25=3;
                }
                break;
            case SLASH:
                {
                alt25=4;
                }
                break;
            case CALL:
                {
                alt25=5;
                }
                break;
            case NOT:
                {
                alt25=6;
                }
                break;
            case IDENT:
                {
                alt25=7;
                }
                break;
            case NUMBER:
                {
                alt25=8;
                }
                break;
            case STRING:
                {
                alt25=9;
                }
                break;
            case BOOLEAN:
                {
                alt25=10;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;

            }

            switch (alt25) {
                case 1 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:356:3: ^(p= PLUS e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,PLUS,FOLLOW_PLUS_in_param_expr1894); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_param_expr1898);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_param_expr1902);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 357:3: -> paramplus(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("paramplus",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 2 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:360:3: ^(p= MINUS e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,MINUS,FOLLOW_MINUS_in_param_expr1934); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_param_expr1938);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_param_expr1942);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 361:3: -> paramminus(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("paramminus",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 3 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:364:3: ^(p= TIMES e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,TIMES,FOLLOW_TIMES_in_param_expr1974); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_param_expr1978);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_param_expr1982);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 365:3: -> paramtimes(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("paramtimes",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 4 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:368:3: ^(p= SLASH e1= expr e2= expr )
                    {
                    p=(PascalTree)match(input,SLASH,FOLLOW_SLASH_in_param_expr2014); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_param_expr2018);
                    e1=expr();

                    state._fsp--;


                    pushFollow(FOLLOW_expr_in_param_expr2022);
                    e2=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 369:3: -> paramslash(e1=$e1.ste2=$e2.st)
                    {
                        retval.st = templateLib.getInstanceOf("paramslash",new STAttrMap().put("e1", (e1!=null?e1.st:null)).put("e2", (e2!=null?e2.st:null)));
                    }



                    }
                    break;
                case 5 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:372:3: ^( CALL i1= IDENT ( ^( FUNCTIONAL_PARAM (e+= expr )+ ) )? )
                    {
                    match(input,CALL,FOLLOW_CALL_in_param_expr2057); 

                    match(input, Token.DOWN, null); 
                    i1=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_param_expr2061); 

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:374:5: ( ^( FUNCTIONAL_PARAM (e+= expr )+ ) )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==FUNCTIONAL_PARAM) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:375:7: ^( FUNCTIONAL_PARAM (e+= expr )+ )
                            {
                            match(input,FUNCTIONAL_PARAM,FOLLOW_FUNCTIONAL_PARAM_in_param_expr2076); 

                            match(input, Token.DOWN, null); 
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:375:27: (e+= expr )+
                            int cnt22=0;
                            loop22:
                            do {
                                int alt22=2;
                                int LA22_0 = input.LA(1);

                                if ( (LA22_0==ASSIGN||(LA22_0 >= BOOLEAN && LA22_0 <= CALL)||LA22_0==IDENT||(LA22_0 >= MINUS && LA22_0 <= NUMBER)||LA22_0==PLUS||LA22_0==SLASH||LA22_0==STRING||LA22_0==TIMES) ) {
                                    alt22=1;
                                }


                                switch (alt22) {
                            	case 1 :
                            	    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:375:27: e+= expr
                            	    {
                            	    pushFollow(FOLLOW_expr_in_param_expr2080);
                            	    e=expr();

                            	    state._fsp--;

                            	    if (list_e==null) list_e=new ArrayList();
                            	    list_e.add(e.getTemplate());


                            	    }
                            	    break;

                            	default :
                            	    if ( cnt22 >= 1 ) break loop22;
                                        EarlyExitException eee =
                                            new EarlyExitException(22, input);
                                        throw eee;
                                }
                                cnt22++;
                            } while (true);


                            match(input, Token.UP, null); 


                            }
                            break;

                    }



                          this.globalScope.resolveFunction((i1!=null?i1.getText():null));
                        

                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 381:4: -> paramcall(cally=$i1e=$e)
                    {
                        retval.st = templateLib.getInstanceOf("paramcall",new STAttrMap().put("cally", i1).put("e", list_e));
                    }



                    }
                    break;
                case 6 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:384:3: ^( NOT ex= expr )
                    {
                    match(input,NOT,FOLLOW_NOT_in_param_expr2130); 

                    match(input, Token.DOWN, null); 
                    pushFollow(FOLLOW_expr_in_param_expr2134);
                    ex=expr();

                    state._fsp--;


                    match(input, Token.UP, null); 


                    // TEMPLATE REWRITE
                    // 385:3: -> paramnot(e=$ex.st)
                    {
                        retval.st = templateLib.getInstanceOf("paramnot",new STAttrMap().put("e", (ex!=null?ex.st:null)));
                    }



                    }
                    break;
                case 7 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:387:5: i= IDENT (t= type )?
                    {
                    i=(PascalTree)match(input,IDENT,FOLLOW_IDENT_in_param_expr2158); 

                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:387:13: (t= type )?
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==ARRAY||LA24_0==IDENT) ) {
                        alt24=1;
                    }
                    switch (alt24) {
                        case 1 :
                            // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:387:14: t= type
                            {
                            pushFollow(FOLLOW_type_in_param_expr2163);
                            t=type();

                            state._fsp--;


                            }
                            break;

                    }



                        Symbol s2 = new Symbol();
                        s2.type = t.ret;
                        this.currentScope.addSymbol((i!=null?i.getText():null), s2);
                      

                    // TEMPLATE REWRITE
                    // 393:3: -> paramident(i=$i)
                    {
                        retval.st = templateLib.getInstanceOf("paramident",new STAttrMap().put("i", i));
                    }



                    }
                    break;
                case 8 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:395:5: n= NUMBER
                    {
                    n=(PascalTree)match(input,NUMBER,FOLLOW_NUMBER_in_param_expr2192); 

                    // TEMPLATE REWRITE
                    // 396:3: -> paramnumber(n=$n)
                    {
                        retval.st = templateLib.getInstanceOf("paramnumber",new STAttrMap().put("n", n));
                    }



                    }
                    break;
                case 9 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:398:5: s= STRING
                    {
                    s=(PascalTree)match(input,STRING,FOLLOW_STRING_in_param_expr2216); 

                    // TEMPLATE REWRITE
                    // 399:3: -> paramstring(s=$s)
                    {
                        retval.st = templateLib.getInstanceOf("paramstring",new STAttrMap().put("s", s));
                    }



                    }
                    break;
                case 10 :
                    // /home/mauricio/developer/workspaces/worksace_compiladores/AntLRDT-Test/src/pascal/parser/PascalFunTreeWalker.g:401:5: b= BOOLEAN
                    {
                    b=(PascalTree)match(input,BOOLEAN,FOLLOW_BOOLEAN_in_param_expr2240); 

                    // TEMPLATE REWRITE
                    // 402:3: -> parambool(b=$b)
                    {
                        retval.st = templateLib.getInstanceOf("parambool",new STAttrMap().put("b", b));
                    }



                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "param_expr"

    // Delegated rules


 

    public static final BitSet FOLLOW_PROGRAM_in_program88 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_program92 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_USES_in_program99 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_use_in_program103 = new BitSet(new long[]{0x0000000000800008L});
    public static final BitSet FOLLOW_IMPLEMENTATION_in_program112 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_implementation_in_program114 = new BitSet(new long[]{0x00020020000C0008L});
    public static final BitSet FOLLOW_EOF_in_program122 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IDENT_in_use158 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROCEDURE_in_implementation211 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_implementation215 = new BitSet(new long[]{0x00065C1B818001A0L});
    public static final BitSet FOLLOW_PARAM_in_implementation257 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_param_in_implementation261 = new BitSet(new long[]{0x0000000000800008L});
    public static final BitSet FOLLOW_VAR_in_implementation285 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_var_in_implementation289 = new BitSet(new long[]{0x0000000000800008L});
    public static final BitSet FOLLOW_cmd_in_implementation306 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FUNCTION_in_implementation361 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_implementation365 = new BitSet(new long[]{0x0000000800800000L});
    public static final BitSet FOLLOW_PARAM_in_implementation406 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_param_in_implementation410 = new BitSet(new long[]{0x0000000000800008L});
    public static final BitSet FOLLOW_IDENT_in_implementation427 = new BitSet(new long[]{0x00065C13818001A0L});
    public static final BitSet FOLLOW_VAR_in_implementation457 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_var_in_implementation461 = new BitSet(new long[]{0x0000000000800008L});
    public static final BitSet FOLLOW_cmd_in_implementation478 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FUNCTIONAL_in_implementation538 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_implementation542 = new BitSet(new long[]{0x0000000000900000L});
    public static final BitSet FOLLOW_FUNCTIONAL_PARAM_in_implementation585 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_param_expr_in_implementation589 = new BitSet(new long[]{0x0000541380800188L});
    public static final BitSet FOLLOW_IDENT_in_implementation606 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_implementation610 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_implementation660 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_var_in_implementation664 = new BitSet(new long[]{0x0000000000800008L});
    public static final BitSet FOLLOW_IDENT_in_param700 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_in_param704 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EQUALS_in_cond774 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_cond778 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_cond782 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DIFFERENT_in_cond824 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_cond828 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_cond832 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LET_in_cond872 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_cond876 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_cond880 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_GET_in_cond920 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_cond924 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_cond928 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_GT_in_cond968 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_cond972 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_cond976 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LT_in_cond1016 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_cond1020 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_cond1024 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STM_LIST_in_cmd1069 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_cmd_in_cmd1073 = new BitSet(new long[]{0x00045C13818001A8L});
    public static final BitSet FOLLOW_IF_in_cmd1101 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_cond_in_cmd1105 = new BitSet(new long[]{0x00045C13818001A0L});
    public static final BitSet FOLLOW_cmd_in_cmd1109 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WHILE_in_cmd1141 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_cond_in_cmd1145 = new BitSet(new long[]{0x00045C13818001A0L});
    public static final BitSet FOLLOW_cmd_in_cmd1149 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expr_in_cmd1182 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ASSIGN_in_expr1223 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_expr1227 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_expr1231 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_in_expr1272 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1276 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_expr1280 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_in_expr1318 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1322 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_expr1326 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TIMES_in_expr1364 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1368 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_expr1372 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SLASH_in_expr1410 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1414 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_expr1418 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_expr1461 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_expr1465 = new BitSet(new long[]{0x0000000000100008L});
    public static final BitSet FOLLOW_FUNCTIONAL_PARAM_in_expr1480 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1484 = new BitSet(new long[]{0x00005413808001A8L});
    public static final BitSet FOLLOW_NOT_in_expr1531 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_expr1535 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IDENT_in_expr1563 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_expr1600 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_expr1636 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BOOLEAN_in_expr1672 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENT_in_var1720 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_in_var1724 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENT_in_type1791 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_in_type1828 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_NUMBER_in_type1832 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_NUMBER_in_type1836 = new BitSet(new long[]{0x0000000000800010L});
    public static final BitSet FOLLOW_type_in_type1840 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_in_param_expr1894 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_param_expr1898 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_param_expr1902 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_in_param_expr1934 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_param_expr1938 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_param_expr1942 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TIMES_in_param_expr1974 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_param_expr1978 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_param_expr1982 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SLASH_in_param_expr2014 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_param_expr2018 = new BitSet(new long[]{0x00005413808001A0L});
    public static final BitSet FOLLOW_expr_in_param_expr2022 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CALL_in_param_expr2057 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IDENT_in_param_expr2061 = new BitSet(new long[]{0x0000000000100008L});
    public static final BitSet FOLLOW_FUNCTIONAL_PARAM_in_param_expr2076 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_param_expr2080 = new BitSet(new long[]{0x00005413808001A8L});
    public static final BitSet FOLLOW_NOT_in_param_expr2130 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_param_expr2134 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IDENT_in_param_expr2158 = new BitSet(new long[]{0x0000000000800012L});
    public static final BitSet FOLLOW_type_in_param_expr2163 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_param_expr2192 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_param_expr2216 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BOOLEAN_in_param_expr2240 = new BitSet(new long[]{0x0000000000000002L});

}